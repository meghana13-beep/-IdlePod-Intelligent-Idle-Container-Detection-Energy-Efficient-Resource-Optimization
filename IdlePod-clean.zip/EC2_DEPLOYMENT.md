# IdlePod EC2 Deployment

Use this only after the local demo works.

## 1. Launch EC2

- OS: Ubuntu 22.04 or 24.04
- Instance size: `t3.medium` or bigger
- Security group inbound:
  - SSH `22`
  - Frontend `3000`
  - Backend `8000`

## 2. Install runtime

```bash
sudo apt update
sudo apt install -y docker.io docker-compose-plugin git
sudo usermod -aG docker ubuntu
newgrp docker
```

## 3. Copy project to EC2

Clone or upload the `IdlePod` folder.

```bash
cd IdlePod
```

## 4. Configure backend environment

Create `backend/.env` on EC2 with the same values used locally:

```text
AWS_SIMULATE=false
AWS_REGION=your-region
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
SNS_TOPIC_ARN=your-topic-arn
S3_BUCKET_NAME=your-bucket-name
LAMBDA_FUNCTION_NAME=IdlePodScaleDownExecutor
MONGODB_URI=your-mongodb-uri
MONGODB_DB=idlepod
CORS_ORIGINS=http://YOUR_EC2_PUBLIC_IP:3000
JWT_SECRET_KEY=change-this-to-a-demo-secret
ADMIN_USERNAME=admin
ADMIN_PASSWORD=IdlePodAdmin2026
```

## 5. Start full stack

```bash
export VITE_API_BASE=http://YOUR_EC2_PUBLIC_IP:8000
docker compose up --build
```

Open:

```text
http://YOUR_EC2_PUBLIC_IP:3000
```

## Notes

- If Kubernetes is not installed on EC2, IdlePod can still show simulator data.
- For a real EC2 Kubernetes demo, install Minikube/kubectl on EC2 and make sure `kubectl get nodes` works before starting Docker Compose.
- Keep AWS keys and MongoDB URI only in `backend/.env`; do not commit them.
