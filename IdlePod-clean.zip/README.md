# IdlePod

Intelligent Green-Cloud Kubernetes pod optimization system that detects underutilized workloads using heuristic scoring, ML anomaly detection, and automated scaling — with real-time cost and carbon savings analytics.

## Quick Start

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

### Docker (Full Stack)

```bash
docker-compose up --build
```

Backend runs on `http://localhost:8000`, frontend on `http://localhost:3000`.

## Runtime Files (Not in Version Control)

The following files are auto-generated at runtime and excluded via `.gitignore`:

| File | Description |
|------|-------------|
| `backend/idlepod.db` | SQLite database storing pod metrics, optimization history, and analytics snapshots. Created automatically on first run. |
| `stderr.txt` | Captured standard error output from background monitoring processes. |
| `stdout.txt` | Captured standard output and telemetry logs from the monitoring loop. |

These files do not need to be committed — they are recreated each time the backend starts.

## ML Models

The machine learning anomaly detection engine requires two pre-trained model files:

- `backend/idlepod_model.pkl` — Isolation Forest model for pod behavior anomaly detection
- `backend/idlepod_scaler.pkl` — Feature scaler fitted to training data distributions

These files are **not included in version control** due to their binary size. To obtain them:

1. Open the IdlePod training Colab notebook
2. Run all cells to train the model on your cluster telemetry data
3. Download the generated `.pkl` files
4. Place both files in the `backend/` directory

The backend will still start without these files, but ML-based anomaly verification will be disabled.

## Project Structure

```
IdlePod/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI application and REST endpoints
│   │   ├── config.py            # Pydantic settings and environment config
│   │   ├── database.py          # SQLite database operations
│   │   ├── heuristic_engine.py  # Weighted idle scoring engine
│   │   ├── optimization_engine.py # Scaling logic with safety checks
│   │   ├── analytics_engine.py  # Cost and energy savings calculator
│   │   ├── ml_engine.py         # Isolation Forest anomaly detection
│   │   └── utils.py             # CPU/memory unit conversion helpers
│   ├── tests/                   # Pytest test suite
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   │   └── App.jsx              # React dashboard UI
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
└── .gitignore
```
