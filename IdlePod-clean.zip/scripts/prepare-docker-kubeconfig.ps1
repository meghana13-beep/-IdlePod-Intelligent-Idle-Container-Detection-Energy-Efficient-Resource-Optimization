$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$sourceKubeConfig = Join-Path $env:USERPROFILE ".kube\config"
$sourceMinikube = Join-Path $env:USERPROFILE ".minikube"

$targetKubeDir = Join-Path $projectRoot "data\kube"
$targetMinikubeDir = Join-Path $projectRoot "data\minikube"
$targetProfileDir = Join-Path $targetMinikubeDir "profiles\minikube"
$targetKubeConfig = Join-Path $targetKubeDir "config"

if (!(Test-Path $sourceKubeConfig)) {
    throw "Kubeconfig not found at $sourceKubeConfig. Start Minikube first, then run this script again."
}

New-Item -ItemType Directory -Force -Path $targetKubeDir | Out-Null
New-Item -ItemType Directory -Force -Path $targetMinikubeDir | Out-Null
New-Item -ItemType Directory -Force -Path $targetProfileDir | Out-Null

Copy-Item -Force (Join-Path $sourceMinikube "ca.crt") (Join-Path $targetMinikubeDir "ca.crt")
Copy-Item -Force (Join-Path $sourceMinikube "profiles\minikube\client.crt") (Join-Path $targetProfileDir "client.crt")
Copy-Item -Force (Join-Path $sourceMinikube "profiles\minikube\client.key") (Join-Path $targetProfileDir "client.key")

$config = Get-Content $sourceKubeConfig -Raw
$config = $config -replace [regex]::Escape($sourceMinikube), "/root/.minikube"
$config = $config -replace "\\", "/"
$config = $config -replace "server: https://(127\.0\.0\.1|localhost):(\d+)", 'server: https://host.docker.internal:$2'
$config = $config -replace "certificate-authority: /root/.minikube/ca.crt", "insecure-skip-tls-verify: true"

Set-Content -Path $targetKubeConfig -Value $config -Encoding ascii

Write-Host "Docker kubeconfig created:"
Write-Host "  $targetKubeConfig"
Write-Host "Docker Compose can now mount ./data/kube and ./data/minikube."
