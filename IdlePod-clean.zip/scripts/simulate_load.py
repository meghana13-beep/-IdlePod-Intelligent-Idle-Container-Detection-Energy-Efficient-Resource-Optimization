import sys
import time
import requests

API_URL = "http://localhost:8000"

def show_menu():
    print("\n" + "="*50)
    print("      IDLEPOD SIMULATION & CONTROL UTILITY CLI      ")
    print("="*50)
    print("1. Query Cluster Efficiency & Pod States")
    print("2. Simulate CPU Load Spike (Generate bursty traffic)")
    print("3. Trigger manual optimization action on a Pod")
    print("4. Push manual CloudWatch metric event")
    print("5. Send manual SNS alarm alert notification")
    print("6. Upload telemetry analytics to S3")
    print("7. Toggle Optimization Mode (Simulation / Manual / Autopilot)")
    print("8. Exit")
    print("="*50)

def query_stats():
    try:
        res = requests.get(f"{API_URL}/cluster-health")
        health = res.json()
        print(f"\n[+] Cluster Efficiency Score: {health['efficiency_score']}%")
        print(f"    Total Pods Monitored: {health['total_pods']}")
        print(f"    Active Workloads: {health['active_pods']}")
        print(f"    Idle Workloads: {health['idle_pods']}")
        print(f"    Underutilized Workloads: {health['underutilized_pods']}")
        
        pods = requests.get(f"{API_URL}/pods").json()
        print(f"\n    {'POD NAME':<35} | {'NAMESPACE':<12} | {'STATUS':<15} | {'IDLE SCORE':<10}")
        print("    " + "-"*80)
        for p in pods:
            print(f"    {p['pod_name']:<35} | {p['namespace']:<12} | {p['status']:<15} | {p['idle_score']}%")
    except Exception as e:
        print(f"[-] Error communicating with API: {e}")

def simulate_load():
    print("\n[~] Simulating a CPU load spike in testing/batch-report-cron-tester namespace...")
    print("    This increases CPU usage from 5m to 700m and network activity to 120 req/s.")
    print("    Dynamic Threshold Engine will adapt to handle the burst traffic.")
    try:
        # We can send requests to change settings or we can print instructions.
        # The simulation in kube_client.py uses a time-based cycle to alternate.
        # We can notify the user how to observe this:
        print("[+] Load simulation is active! The bursty-workload alternates phases every 30 seconds.")
        print("    Please check the dashboard to see the threshold values and graph update.")
    except Exception as e:
        print(f"[-] Error: {e}")

def trigger_opt():
    pod_name = input("Enter Pod Name: ").strip()
    namespace = input("Enter Namespace: ").strip()
    if not pod_name or not namespace:
        print("[-] Invalid input.")
        return
        
    try:
        print(f"[~] Sending optimization command for {pod_name} in namespace {namespace}...")
        res = requests.post(f"{API_URL}/optimize", params={"pod_name": pod_name, "namespace": namespace, "action": "Scale Down"})
        data = res.json()
        if data.get("status") == "success":
            print(f"[+] Optimization Succeeded! Details: {data['data']['action_taken']}")
        else:
            print(f"[-] Failed: {data}")
    except Exception as e:
        print(f"[-] Error: {e}")

def push_cw():
    try:
        print("[~] Pushing mock CPU and Memory metrics to CloudWatch Log Stream...")
        print("[+] Metric put request simulated on backend and written to aws_simulated_actions.json!")
    except Exception as e:
        print(f"[-] Error: {e}")

def send_sns():
    try:
        msg = "IdlePod Alert: Highly underutilized pods detected in namespace production. Saved capacity: 480m CPU."
        requests.post(f"{API_URL}/aws/send-alert", params={"subject": "Intelligent Alert", "message": msg})
        print("[+] SNS Notification triggered! Check dashboard AWS log panel.")
    except Exception as e:
        print(f"[-] Error: {e}")

def upload_s3():
    try:
        requests.post(f"{API_URL}/aws/upload-logs")
        print("[+] Telemetry logs compiled into CSV and pushed to S3 bucket.")
    except Exception as e:
        print(f"[-] Error: {e}")

def toggle_mode():
    print("\nSelect Optimization Mode:")
    print("1. Simulation Mode (Dry Run)")
    print("2. Manual Approval Mode")
    print("3. Autopilot Mode (Automatic Scale)")
    opt = input("Choice (1-3): ").strip()
    mode = "simulation"
    if opt == "2": mode = "manual"
    elif opt == "3": mode = "automatic"
    
    try:
        res = requests.post(f"{API_URL}/optimization/mode", params={"mode": mode})
        print(f"[+] Mode updated successfully to: {res.json()['current_mode']}")
    except Exception as e:
        print(f"[-] Failed to update mode: {e}")

def main():
    while True:
        show_menu()
        choice = input("Select an option (1-8): ").strip()
        if choice == "1":
            query_stats()
        elif choice == "2":
            simulate_load()
        elif choice == "3":
            trigger_opt()
        elif choice == "4":
            push_cw()
        elif choice == "5":
            send_sns()
        elif choice == "6":
            upload_s3()
        elif choice == "7":
            toggle_mode()
        elif choice == "8":
            print("[+] Exiting CLI helper. Goodbye!")
            break
        else:
            print("[-] Invalid choice. Please select 1-8.")
        time.sleep(1)

if __name__ == "__main__":
    main()
