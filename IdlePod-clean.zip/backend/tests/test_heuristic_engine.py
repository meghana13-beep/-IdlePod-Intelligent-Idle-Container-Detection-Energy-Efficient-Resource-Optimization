import pytest
from app.heuristic_engine import heuristic_engine

def test_calculate_idle_score_idle_pod():
    pod = {
        "cpu_usage": 2, "memory_usage": 5, "network_activity": 0, 
        "uptime": 150, "restart_count": 0, "status": "Running"
    }
    score, status, priority = heuristic_engine.calculate_idle_score(pod, 50, 50)
    assert score > 70
    assert status == "Idle"

def test_calculate_idle_score_active_pod():
    pod = {
        "cpu_usage": 800, "memory_usage": 900, "network_activity": 50, 
        "uptime": 150, "restart_count": 0, "status": "Running"
    }
    score, status, priority = heuristic_engine.calculate_idle_score(pod, 50, 50)
    assert score <= 40
    assert status == "Active"

def test_calculate_idle_score_crashing_pod():
    pod_stable = {
        "cpu_usage": 2, "memory_usage": 5, "network_activity": 0, 
        "uptime": 150, "restart_count": 0, "status": "Running"
    }
    score_stable, _, _ = heuristic_engine.calculate_idle_score(pod_stable, 50, 50)
    
    pod_crashing = {
        "cpu_usage": 2, "memory_usage": 5, "network_activity": 0, 
        "uptime": 150, "restart_count": 5, "status": "Running"
    }
    score_crashing, _, _ = heuristic_engine.calculate_idle_score(pod_crashing, 50, 50)
    
    assert score_crashing == max(0, score_stable - 20)

def test_calculate_idle_score_non_running():
    pod = {"status": "Pending"}
    score, status, priority = heuristic_engine.calculate_idle_score(pod, 50, 50)
    assert score == 0
    assert status == "Inactive"
    assert priority == "Low"
