import pytest
from app.utils import convert_memory_to_mb, convert_cpu_to_millicores

def test_convert_memory_to_mb(capsys):
    assert convert_memory_to_mb('256Mi') == 256.0
    assert convert_memory_to_mb('1Gi') == 1024.0
    assert convert_memory_to_mb('1024Ki') == 1.0
    
    assert convert_memory_to_mb('500m') == 0.0
    captured = capsys.readouterr()
    assert "[WARNING]" in captured.out
    
    assert convert_memory_to_mb('') == 0.0
    assert convert_memory_to_mb('1048576') == 1.0

def test_convert_cpu_to_millicores():
    assert convert_cpu_to_millicores('100m') == 100
    assert convert_cpu_to_millicores('0.5') == 500
    assert convert_cpu_to_millicores('1') == 1000
    assert convert_cpu_to_millicores('500n') == 0
    assert convert_cpu_to_millicores('') == 0
