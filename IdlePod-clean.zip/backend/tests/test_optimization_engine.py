import pytest
from unittest.mock import patch
from app.optimization_engine import optimization_engine

@patch("app.optimization_engine.db.save_optimization")
@patch("app.optimization_engine.db.save_alert")
def test_set_mode(mock_save_alert, mock_save_opt):
    assert optimization_engine.set_mode("simulation") == True
    assert optimization_engine.mode == "simulation"
    
    assert optimization_engine.set_mode("manual") == True
    assert optimization_engine.mode == "manual"
    
    assert optimization_engine.set_mode("automatic") == True
    assert optimization_engine.mode == "automatic"
    
    assert optimization_engine.set_mode("invalid_mode") == False
    assert optimization_engine.mode == "automatic" # unchanged

@patch("app.optimization_engine.db.save_optimization")
@patch("app.optimization_engine.db.save_alert")
def test_generate_recommendation(mock_save_alert, mock_save_opt):
    pod_high = {"pod_name": "test-pod-1", "namespace": "default", "idle_score": 90}
    rec_high = optimization_engine.generate_recommendation(pod_high)
    assert rec_high["priority"] == "High"
    
    pod_medium = {"pod_name": "test-pod-2", "namespace": "default", "idle_score": 60}
    rec_medium = optimization_engine.generate_recommendation(pod_medium)
    assert rec_medium["priority"] == "Medium"
