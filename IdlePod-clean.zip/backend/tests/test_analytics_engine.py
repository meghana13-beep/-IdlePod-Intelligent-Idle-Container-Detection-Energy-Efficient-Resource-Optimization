import pytest
from unittest.mock import patch
from app.analytics_engine import analytics_engine

@patch("app.analytics_engine.db.get_optimizations")
@patch("app.analytics_engine.db.save_analytics")
def test_calculate_savings(mock_save_analytics, mock_get_opt):
    mock_get_opt.return_value = [
        {
            "resources_saved": "500m CPU, 256Mi Memory", 
            "optimization_status": "Completed", 
            "timestamp": "2024-01-01T00:00:00"
        }
    ]
    
    result = analytics_engine.calculate_savings()
    
    expected_keys = [
        "total_cpu_saved_m", "total_memory_saved_mb", "hourly_cost_saving_usd", 
        "cumulative_cost_saved_usd", "cumulative_kwh_saved", "cumulative_co2_offset_g", 
        "savings_disclaimer"
    ]
    
    for key in expected_keys:
        assert key in result
        
    assert isinstance(result["cumulative_cost_saved_usd"], float)
    assert result["cumulative_cost_saved_usd"] > 0
