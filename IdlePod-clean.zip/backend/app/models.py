from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class PodMetricSchema(BaseModel):
    pod_name: str
    namespace: str
    cpu_usage: float            # In millicores
    memory_usage: float         # In MB
    cpu_requested: str          # e.g., '100m'
    memory_requested: str       # e.g., '256Mi'
    network_activity: float     # requests/sec (mocked or metrics)
    request_frequency: float = 0.0
    node_name: Optional[str] = None
    workload_name: Optional[str] = None
    workload_kind: Optional[str] = None
    replica_count: int = 0
    idle_score: int             # 0 - 100
    ml_prediction: str          # Active, Idle, Anomaly
    status: str                 # Active, Underutilized, Idle
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class OptimizationActionSchema(BaseModel):
    id: Optional[int] = None
    pod_name: str
    namespace: str
    action_taken: str           # e.g., 'Scale Replicas', 'Delete Pod', 'Notify Admin'
    resources_saved: str        # e.g., '200m CPU, 128Mi Memory'
    optimization_status: str    # e.g., 'Completed', 'Approved', 'Simulated'
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class AlertSchema(BaseModel):
    id: Optional[int] = None
    alert_type: str             # e.g., 'IdlePod', 'HighUtil', 'ResourceWastage'
    severity: str               # e.g., 'Info', 'Warning', 'Critical'
    message: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class EnergyAnalyticsSchema(BaseModel):
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    total_cpu_saved: float      # Millicores
    total_memory_saved: float   # MB
    energy_saved: float         # Watts
    estimated_cost_reduction: float # USD

class ClusterHealthSchema(BaseModel):
    total_pods: int
    active_pods: int
    idle_pods: int
    underutilized_pods: int
    total_cpu_requested: int
    total_cpu_used: int
    efficiency_score: int       # 0 - 100
