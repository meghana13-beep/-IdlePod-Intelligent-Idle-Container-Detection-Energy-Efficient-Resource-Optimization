import numpy as np
import joblib
import os
import json

class MLEngine:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.meta = {}
        self.trained = False
        self._load_model()

    def _load_model(self):
        model_path  = os.path.join(os.path.dirname(__file__), "..", "idlepod_model.pkl")
        scaler_path = os.path.join(os.path.dirname(__file__), "..", "idlepod_scaler.pkl")
        meta_path   = os.path.join(os.path.dirname(__file__), "..", "model_metadata.json")

        try:
            self.model  = joblib.load(model_path)
            self.scaler = joblib.load(scaler_path)
            if os.path.exists(meta_path):
                with open(meta_path) as f:
                    self.meta = json.load(f)
            self.meta.setdefault("model_name", "IdlePod Isolation Forest")
            self.meta.setdefault("model_type", "unsupervised")
            self.meta.setdefault("test_f1", "demo-unlabeled")
            self.meta.setdefault("test_precision", "demo-unlabeled")
            self.meta.setdefault("test_recall", "demo-unlabeled")
            self.trained = True
            print(f"ML Model loaded: {self.meta.get('model_name')} | "
                  f"Test F1={self.meta.get('test_f1')} | "
                  f"Precision={self.meta.get('test_precision')} | "
                  f"Recall={self.meta.get('test_recall')}")
        except Exception as e:
            print(f"Failed to load ML model: {e}. Falling back to rule-based prediction.")
            self.trained = False

    def train_model(self):
        # Model is pre-trained. Nothing to do at runtime.
        return self.trained

    def predict_anomaly(self, pod):
        if not self.trained or self.model is None:
            # Rule-based fallback
            if pod.get("cpu_usage", 0) < 15.0 and pod.get("network_activity", 0) < 1.0:
                return "Anomaly"
            return "Normal"

        try:
            feats = np.array([[
                float(pod.get('cpu_usage', 0)),
                float(pod.get('memory_usage', 0)),
                float(pod.get('network_activity', 0)),
                float(pod.get('uptime', 0)),
                float(pod.get('restart_count', 0))
            ]])
            feats_scaled = self.scaler.transform(feats)

            if self.meta.get('model_type') == 'unsupervised':
                raw = self.model.predict(feats_scaled)[0]
                pred = 1 if raw == -1 else 0
            else:
                pred = self.model.predict(feats_scaled)[0]

            return "Anomaly" if pred == 1 else "Normal"
        except Exception as e:
            print(f"ML prediction error: {e}")
            return "Normal"

ml_engine = MLEngine()
