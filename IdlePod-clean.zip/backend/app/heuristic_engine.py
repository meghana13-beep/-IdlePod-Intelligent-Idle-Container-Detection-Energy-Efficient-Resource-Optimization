class HeuristicEngine:
    WEIGHT_CPU      = 30  # CPU is the primary billing dimension in Kubernetes; highest weight
    WEIGHT_MEMORY   = 25  # Memory is second largest cost factor in cloud node pricing
    WEIGHT_NETWORK  = 20  # Zero network traffic strongly indicates no active workload
    WEIGHT_REQUESTS = 15  # Request rate corroborates network silence
    WEIGHT_UPTIME   = 10  # Ensures pods are stable before flagging, not just warming up
    # Total = 100 points. Thresholds: 0-40 Active, 41-70 Underutilized, 71-100 Idle

    def calculate_idle_score(self, pod, dynamic_cpu_thresh, dynamic_mem_thresh):
        """
        Calculates an Idle Confidence Score (0-100) using weighted heuristics.
        Weights are tuned for general-purpose web/API workloads.
        For batch processing or GPU workloads, recalibrate WEIGHT_* constants accordingly.
        Score bands: 0-40 = Active, 41-70 = Underutilized, 71-100 = Idle
        """
        # If pod is not Running, it's not idle, it's either starting, succeeding, failing or pending.
        if pod.get("status") != "Running":
            return 0, "Inactive", "Low"
            
        cpu_usage = pod.get("cpu_usage", 0.0)
        mem_usage = pod.get("memory_usage", 0.0)
        network = pod.get("network_activity", 0.0)
        uptime = pod.get("uptime", 0)
        restarts = pod.get("restart_count", 0)
        
        idle_score = 0
        
        # 1. CPU relative to dynamic threshold (Max: 30 pts)
        if cpu_usage < dynamic_cpu_thresh:
            # Let's scale points: if usage is extremely low (e.g. < 10% of threshold), give full weight.
            ratio = cpu_usage / max(1.0, dynamic_cpu_thresh)
            if ratio < 0.1:
                idle_score += self.WEIGHT_CPU
            elif ratio < 0.5:
                idle_score += 20
            else:
                idle_score += 10
                
        # 2. Memory relative to dynamic threshold (Max: 25 pts)
        if mem_usage < dynamic_mem_thresh:
            ratio = mem_usage / max(1.0, dynamic_mem_thresh)
            if ratio < 0.1:
                idle_score += self.WEIGHT_MEMORY
            elif ratio < 0.5:
                idle_score += 15
            else:
                idle_score += 8
                
        # 3. Network activity / mock load (Max: 20 pts)
        if network == 0.0:
            idle_score += self.WEIGHT_NETWORK
        elif network < 1.0:
            idle_score += 15
        elif network < 5.0:
            idle_score += 5
            
        # 4. Request count (equivalent to network requests/sec here) (Max: 15 pts)
        # In our metrics map, network acts as requests/sec
        if network < 2.0:
            idle_score += self.WEIGHT_REQUESTS
        elif network < 10.0:
            idle_score += 8
            
        # 5. Pod uptime (Max: 10 pts)
        # Avoid optimizing brand-new pods that might still be warming up
        if uptime > 120:    # 2 hours stable
            idle_score += self.WEIGHT_UPTIME
        elif uptime > 30:   # 30 mins stable
            idle_score += 5
            
        # Deduct score if pod is unstable / crashing (high restarts)
        # Unstable pods should not be treated as "idle", they need troubleshooting, not replica scale-down
        if restarts > 3:
            idle_score = max(0, idle_score - 20)
            
        # Determine status
        if idle_score <= 40:
            status = "Active"
            priority = "Low"
        elif idle_score <= 70:
            status = "Underutilized"
            priority = "Medium"
        else:
            status = "Idle"
            priority = "High"
            
        return int(idle_score), status, priority

heuristic_engine = HeuristicEngine()
