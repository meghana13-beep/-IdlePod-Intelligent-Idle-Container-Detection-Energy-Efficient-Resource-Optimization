import datetime

def convert_cpu_to_millicores(cpu_str):
    """
    Convert Kubernetes CPU string to millicores (integer).
    Examples: '100m' -> 100, '0.5' -> 500, '1' -> 1000
    """
    if not cpu_str:
        return 0
    cpu_str = str(cpu_str).strip()
    if cpu_str.endswith('m'):
        return int(cpu_str[:-1])
    elif cpu_str.endswith('n'):
        return int(cpu_str[:-1]) // 1_000_000 # Convert nanocores to millicores
    else:
        try:
            return int(float(cpu_str) * 1000)
        except ValueError:
            return 0

def convert_memory_to_mb(memory_str):
    """
    Convert Kubernetes memory string to MB (float).
    Examples: '256Mi' -> 256, '1Gi' -> 1024, '1024Ki' -> 1
    """
    if not memory_str:
        return 0.0
    
    memory_str = str(memory_str).strip()
    if memory_str == "":
        return 0.0
        
    if memory_str.endswith('Ki'):
        return float(memory_str[:-2]) / 1024
    elif memory_str.endswith('Mi'):
        return float(memory_str[:-2])
    elif memory_str.endswith('Gi'):
        return float(memory_str[:-2]) * 1024
    elif memory_str.endswith('m'):
        print(f"[WARNING] convert_memory_to_mb: unsupported millicore/millibyte notation '{memory_str}'. Returning 0.0.")
        return 0.0
    elif memory_str.isdigit():
        # Plain bytes — converting to MB
        return float(memory_str) / (1024 * 1024)
    else:
        try:
            return float(memory_str)
        except ValueError:
            return 0.0

def get_current_timestamp():
    """Return a formatted current time string."""
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def print_log(message):
    """Print message with current timestamp."""
    print(f"[{get_current_timestamp()}] {message}")
