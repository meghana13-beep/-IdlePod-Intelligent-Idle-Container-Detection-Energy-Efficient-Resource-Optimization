import os
import json
import csv
from datetime import datetime, timedelta
from app.config import settings

# Attempt boto3 import
try:
    import boto3
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

class AWSClient:
    def __init__(self):
        self.simulate = settings.AWS_SIMULATE or not BOTO3_AVAILABLE
        self.log_file = "aws_simulated_actions.json"
        
        self.cw = None
        self.sns = None
        self.s3 = None
        self.awslambda = None
        self.ce = None
        
        if not self.simulate:
            try:
                # Initialize real AWS SDK clients using config credentials
                session = boto3.Session(
                    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
                    region_name=settings.AWS_REGION
                )
                self.cw = session.client('cloudwatch')
                self.sns = session.client('sns')
                self.s3 = session.client('s3')
                self.awslambda = session.client('lambda')
                self.ce = session.client('ce', region_name='us-east-1')
                print("AWS Services (CloudWatch, SNS, S3, Lambda, Cost Explorer) initialized successfully.")
            except Exception as e:
                print(f"Failed to initialize real AWS SDK: {e}. Switching to AWS SIMULATOR.")
                self.simulate = True

    def _log_action(self, service, action, payload, status):
        """Write AWS requests to a local JSON audit log for the dashboard."""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "service": service,
            "action": action,
            "payload": payload,
            "status": status
        }
        
        logs = []
        if os.path.exists(self.log_file):
            try:
                with open(self.log_file, 'r') as f:
                    logs = json.load(f)
            except Exception:
                pass
                
        logs.append(log_entry)
        # Keep last 50 entries
        if len(logs) > 50:
            logs.pop(0)
            
        with open(self.log_file, 'w') as f:
            json.dump(logs, f, indent=2)

    def _log_simulation(self, service, action, payload):
        """Helper to write AWS simulated requests to a local JSON log file for audit/dashboard."""
        self._log_action(service, action, payload, "SIMULATED_SUCCESS")

    def get_simulation_logs(self):
        """Reads local simulated logs to display in the AWS console dashboard tab."""
        if os.path.exists(self.log_file):
            try:
                with open(self.log_file, 'r') as f:
                    return json.load(f)[::-1] # newest first
            except Exception:
                return []
        return []

    # CLOUDWATCH METRICS
    def push_metric(self, name, value, unit='Percent', dimensions=None):
        payload = {
            'Namespace': settings.CLOUDWATCH_NAMESPACE,
            'MetricData': [
                {
                    'MetricName': name,
                    'Value': value,
                    'Unit': unit,
                    'Dimensions': dimensions or []
                }
            ]
        }
        
        if self.simulate:
            self._log_simulation("CloudWatch", "PutMetricData", payload)
            return True
            
        try:
            self.cw.put_metric_data(**payload)
            self._log_action("CloudWatch", "PutMetricData", payload, "REAL_SUCCESS")
            return True
        except Exception as e:
            print(f"CloudWatch PutMetricData error: {e}")
            self._log_action("CloudWatch", "PutMetricData", payload, "REAL_FAILED")
            return False

    # SNS NOTIFICATIONS
    def send_notification(self, subject, message):
        payload = {
            'TopicArn': settings.SNS_TOPIC_ARN,
            'Message': message,
            'Subject': subject
        }
        
        if self.simulate:
            self._log_simulation("SNS", "Publish", payload)
            return True
            
        try:
            self.sns.publish(**payload)
            self._log_action("SNS", "Publish", payload, "REAL_SUCCESS")
            return True
        except Exception as e:
            print(f"SNS Publish error: {e}")
            self._log_action("SNS", "Publish", payload, "REAL_FAILED")
            return False

    # S3 REPORT UPLOAD
    def upload_report_to_s3(self, filename, data_list):
        """
        Creates a temporary CSV locally and uploads it to S3.
        In simulation mode, saves it directly to a local 'data/s3_mock/' directory.
        """
        # Formulate CSV file
        s3_mock_dir = os.path.join("data", "s3_mock")
        os.makedirs(s3_mock_dir, exist_ok=True)
        local_path = os.path.join(s3_mock_dir, filename)
        
        if not data_list:
            return False
            
        try:
            keys = data_list[0].keys()
            with open(local_path, 'w', newline='') as f:
                dict_writer = csv.DictWriter(f, keys)
                dict_writer.writeheader()
                dict_writer.writerows(data_list)
        except Exception as e:
            print(f"Failed to generate CSV locally: {e}")
            return False

        payload = {
            'Bucket': settings.S3_BUCKET_NAME,
            'Key': f"reports/{filename}",
            'LocalFilePath': local_path
        }
        
        if self.simulate:
            self._log_simulation("S3", "UploadFile", payload)
            return True
            
        try:
            self.s3.upload_file(local_path, settings.S3_BUCKET_NAME, f"reports/{filename}")
            self._log_action("S3", "UploadFile", payload, "REAL_SUCCESS")
            return True
        except Exception as e:
            print(f"S3 Upload error: {e}")
            self._log_action("S3", "UploadFile", payload, "REAL_FAILED")
            return False

    # LAMBDA WORKFLOW AUTOMATION
    def trigger_lambda_optimization(self, event_data):
        payload = {
            'FunctionName': settings.LAMBDA_FUNCTION_NAME,
            'Payload': json.dumps(event_data)
        }
        
        if self.simulate:
            self._log_simulation("Lambda", "Invoke", payload)
            return True
            
        try:
            self.awslambda.invoke(
                FunctionName=payload['FunctionName'],
                InvocationType='Event',
                Payload=payload['Payload']
            )
            self._log_action("Lambda", "Invoke", payload, "REAL_SUCCESS")
            return True
        except Exception as e:
            print(f"Lambda Invoke error: {e}")
            self._log_action("Lambda", "Invoke", payload, "REAL_FAILED")
            return False

    # COST EXPLORER BILLING ANALYTICS
    def get_daily_costs(self, days=None):
        """Fetch daily real AWS unblended cost from Cost Explorer."""
        days = days or settings.COST_EXPLORER_LOOKBACK_DAYS
        end_date = datetime.utcnow().date() + timedelta(days=1)
        start_date = end_date - timedelta(days=days)
        payload = {
            "TimePeriod": {
                "Start": start_date.isoformat(),
                "End": end_date.isoformat()
            },
            "Granularity": "DAILY",
            "Metrics": ["UnblendedCost"]
        }

        if self.simulate or not self.ce:
            self._log_simulation("CostExplorer", "GetCostAndUsage", payload)
            return {
                "status": "simulated",
                "currency": "USD",
                "total_cost_usd": 0.0,
                "average_daily_cost_usd": 0.0,
                "days": [],
                "message": "AWS simulation mode is enabled, so real Cost Explorer data was not requested."
            }

        try:
            response = self.ce.get_cost_and_usage(**payload)
            days_out = []
            total = 0.0
            currency = "USD"
            for item in response.get("ResultsByTime", []):
                amount_raw = item.get("Total", {}).get("UnblendedCost", {}).get("Amount", "0")
                currency = item.get("Total", {}).get("UnblendedCost", {}).get("Unit", currency)
                amount = round(float(amount_raw), 4)
                total += amount
                days_out.append({
                    "date": item.get("TimePeriod", {}).get("Start"),
                    "cost_usd": amount
                })

            total = round(total, 4)
            average = round(total / len(days_out), 4) if days_out else 0.0
            result = {
                "status": "real",
                "currency": currency,
                "total_cost_usd": total,
                "average_daily_cost_usd": average,
                "days": days_out,
                "message": "Real AWS Cost Explorer data. Billing data can be delayed by several hours."
            }
            self._log_action("CostExplorer", "GetCostAndUsage", payload, "REAL_SUCCESS")
            return result
        except Exception as e:
            print(f"Cost Explorer GetCostAndUsage error: {e}")
            self._log_action("CostExplorer", "GetCostAndUsage", payload, "REAL_FAILED")
            return {
                "status": "error",
                "currency": "USD",
                "total_cost_usd": 0.0,
                "average_daily_cost_usd": 0.0,
                "days": [],
                "message": str(e)
            }

aws_client = AWSClient()
