import sqlite3
import os
import json
from datetime import datetime
from app.config import settings

# Attempt MongoDB import
try:
    from pymongo import MongoClient
    MONGODB_AVAILABLE = True
except ImportError:
    MONGODB_AVAILABLE = False

class IdlePodDatabase:
    def __init__(self):
        self.db_type = settings.DB_TYPE
        self.sqlite_path = "idlepod.db"
        
        # Initialize SQLite database schema
        self._init_sqlite()
        
        # Initialize MongoDB connection if requested
        self.mongo_client = None
        self.mongo_db = None
        if self.db_type == "mongodb" and MONGODB_AVAILABLE:
            try:
                self.mongo_client = MongoClient(settings.MONGODB_URI, serverSelectionTimeoutMS=2000)
                # Check connection
                self.mongo_client.server_info()
                self.mongo_db = self.mongo_client[settings.MONGODB_DB]
                print(f"Connected to MongoDB Atlas successfully at {settings.MONGODB_URI}")
            except Exception as e:
                print(f"Failed to connect to MongoDB: {e}. Falling back to SQLite.")
                self.db_type = "sqlite"

    def _init_sqlite(self):
        conn = sqlite3.connect(self.sqlite_path)
        cursor = conn.cursor()
        
        # Table for Pod Metrics
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pod_name TEXT,
                namespace TEXT,
                cpu_usage REAL,
                memory_usage REAL,
                cpu_requested TEXT,
                memory_requested TEXT,
                network_activity REAL,
                request_frequency REAL,
                node_name TEXT,
                idle_score INTEGER,
                ml_prediction TEXT,
                status TEXT,
                workload_name TEXT,
                workload_kind TEXT,
                replica_count INTEGER,
                timestamp TEXT
            )
        ''')
        self._ensure_sqlite_columns(cursor, "pods", {
            "request_frequency": "REAL",
            "node_name": "TEXT",
            "workload_name": "TEXT",
            "workload_kind": "TEXT",
            "replica_count": "INTEGER"
        })
        
        # Table for Optimizations
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS optimizations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pod_name TEXT,
                namespace TEXT,
                action_taken TEXT,
                resources_saved TEXT,
                optimization_status TEXT,
                timestamp TEXT
            )
        ''')
        
        # Table for Alerts
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                alert_type TEXT,
                severity TEXT,
                message TEXT,
                timestamp TEXT
            )
        ''')
        
        # Table for Analytics
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS analytics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                total_cpu_saved REAL,
                total_memory_saved REAL,
                energy_saved REAL,
                estimated_cost_reduction REAL,
                timestamp TEXT
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ml_predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pod_name TEXT,
                namespace TEXT,
                prediction TEXT,
                ml_label TEXT,
                idle_score INTEGER,
                cpu_usage REAL,
                memory_usage REAL,
                network_activity REAL,
                request_frequency REAL,
                uptime REAL,
                restart_count INTEGER,
                timestamp TEXT
            )
        ''')
        
        conn.commit()
        conn.close()

    def _ensure_sqlite_columns(self, cursor, table_name, columns):
        cursor.execute(f"PRAGMA table_info({table_name})")
        existing = {row[1] for row in cursor.fetchall()}
        for column_name, column_type in columns.items():
            if column_name not in existing:
                cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_type}")

    # POD METRICS METHODS
    def save_pod_metrics(self, metrics_list):
        timestamp_str = datetime.utcnow().isoformat()
        
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                snapshot_ts = datetime.utcnow()
                for pod in metrics_list:
                    pod_doc = pod.copy()
                    pod_doc['timestamp'] = snapshot_ts
                    self.mongo_db.pods.insert_one(pod_doc)
                return
            except Exception as e:
                print(f"MongoDB write failed: {e}. Writing to SQLite.")
        
        # Fallback to SQLite
        conn = sqlite3.connect(self.sqlite_path)
        cursor = conn.cursor()
        for pod in metrics_list:
            cursor.execute('''
                INSERT INTO pods (
                    pod_name, namespace, cpu_usage, memory_usage, cpu_requested, 
                    memory_requested, network_activity, request_frequency, node_name,
                    idle_score, ml_prediction, status, workload_name, workload_kind,
                    replica_count, timestamp
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                pod['pod_name'], pod['namespace'], pod['cpu_usage'], pod['memory_usage'],
                pod['cpu_requested'], pod['memory_requested'], pod['network_activity'],
                pod.get('request_frequency', pod.get('network_activity', 0.0)), pod.get('node_name'),
                pod['idle_score'], pod['ml_prediction'], pod['status'],
                pod.get('workload_name'), pod.get('workload_kind'), pod.get('replica_count'),
                timestamp_str
            ))
        conn.commit()
        conn.close()

    def get_latest_pod_metrics(self):
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                # Find the most recent timestamp in database
                latest_record = self.mongo_db.pods.find_one(sort=[("timestamp", -1)])
                if not latest_record:
                    return []
                latest_ts = latest_record['timestamp']
                
                # Fetch all pods with that timestamp
                cursor = self.mongo_db.pods.find({"timestamp": latest_ts})
                pods = []
                for doc in cursor:
                    doc['_id'] = str(doc['_id'])
                    if isinstance(doc['timestamp'], datetime):
                        doc['timestamp'] = doc['timestamp'].isoformat()
                    pods.append(doc)
                return pods
            except Exception as e:
                print(f"MongoDB read failed: {e}. Reading from SQLite.")
                
        # Fallback to SQLite
        conn = sqlite3.connect(self.sqlite_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Find the latest timestamp
        cursor.execute("SELECT MAX(timestamp) FROM pods")
        row = cursor.fetchone()
        latest_ts = row[0] if row else None
        
        if not latest_ts:
            conn.close()
            return []
            
        cursor.execute("SELECT * FROM pods WHERE timestamp = ?", (latest_ts,))
        pods = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return pods

    # OPTIMIZATIONS METHODS
    def save_optimization(self, opt):
        timestamp_str = datetime.utcnow().isoformat()
        
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                opt_doc = opt.copy()
                opt_doc['timestamp'] = datetime.utcnow()
                self.mongo_db.optimizations.insert_one(opt_doc)
                return
            except Exception as e:
                print(f"MongoDB write failed: {e}. Writing to SQLite.")
                
        # SQLite
        conn = sqlite3.connect(self.sqlite_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO optimizations (pod_name, namespace, action_taken, resources_saved, optimization_status, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            opt['pod_name'], opt['namespace'], opt['action_taken'], 
            opt['resources_saved'], opt['optimization_status'], timestamp_str
        ))
        conn.commit()
        conn.close()

    def get_optimizations(self):
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                cursor = self.mongo_db.optimizations.find().sort("timestamp", -1).limit(50)
                opts = []
                for doc in cursor:
                    doc['_id'] = str(doc['_id'])
                    if isinstance(doc['timestamp'], datetime):
                        doc['timestamp'] = doc['timestamp'].isoformat()
                    opts.append(doc)
                return opts
            except Exception as e:
                print(f"MongoDB read failed: {e}. Reading from SQLite.")
                
        # SQLite
        conn = sqlite3.connect(self.sqlite_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM optimizations ORDER BY timestamp DESC LIMIT 50")
        opts = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return opts

    # ALERTS METHODS
    def save_alert(self, alert):
        timestamp_str = datetime.utcnow().isoformat()
        
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                alert_doc = alert.copy()
                alert_doc['timestamp'] = datetime.utcnow()
                self.mongo_db.alerts.insert_one(alert_doc)
                return
            except Exception as e:
                print(f"MongoDB write failed: {e}. Writing to SQLite.")
                
        # SQLite
        conn = sqlite3.connect(self.sqlite_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO alerts (alert_type, severity, message, timestamp)
            VALUES (?, ?, ?, ?)
        ''', (
            alert['alert_type'], alert['severity'], alert['message'], timestamp_str
        ))
        conn.commit()
        conn.close()

    def get_alerts(self):
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                cursor = self.mongo_db.alerts.find().sort("timestamp", -1).limit(50)
                alerts = []
                for doc in cursor:
                    doc['_id'] = str(doc['_id'])
                    if isinstance(doc['timestamp'], datetime):
                        doc['timestamp'] = doc['timestamp'].isoformat()
                    alerts.append(doc)
                return alerts
            except Exception as e:
                print(f"MongoDB read failed: {e}. Reading from SQLite.")
                
        # SQLite
        conn = sqlite3.connect(self.sqlite_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM alerts ORDER BY timestamp DESC LIMIT 50")
        alerts = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return alerts

    # ANALYTICS METHODS
    def save_analytics(self, analytics):
        timestamp_str = datetime.utcnow().isoformat()
        
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                analytics_doc = analytics.copy()
                analytics_doc['timestamp'] = datetime.utcnow()
                self.mongo_db.analytics.insert_one(analytics_doc)
                return
            except Exception as e:
                print(f"MongoDB write failed: {e}. Writing to SQLite.")
                
        # SQLite
        conn = sqlite3.connect(self.sqlite_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO analytics (total_cpu_saved, total_memory_saved, energy_saved, estimated_cost_reduction, timestamp)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            analytics['total_cpu_saved'], analytics['total_memory_saved'], 
            analytics['energy_saved'], analytics['estimated_cost_reduction'], timestamp_str
        ))
        conn.commit()
        conn.close()

    def get_latest_analytics(self):
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                doc = self.mongo_db.analytics.find_one(sort=[("timestamp", -1)])
                if doc:
                    doc['_id'] = str(doc['_id'])
                    if isinstance(doc['timestamp'], datetime):
                        doc['timestamp'] = doc['timestamp'].isoformat()
                    return doc
                return None
            except Exception as e:
                print(f"MongoDB read failed: {e}. Reading from SQLite.")
                
        # SQLite
        conn = sqlite3.connect(self.sqlite_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM analytics ORDER BY timestamp DESC LIMIT 1")
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def get_analytics_history(self):
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                cursor = self.mongo_db.analytics.find().sort("timestamp", 1).limit(100)
                history = []
                for doc in cursor:
                    doc['_id'] = str(doc['_id'])
                    if isinstance(doc['timestamp'], datetime):
                        doc['timestamp'] = doc['timestamp'].isoformat()
                    history.append(doc)
                return history
            except Exception as e:
                print(f"MongoDB read failed: {e}. Reading from SQLite.")
                
        # SQLite
        conn = sqlite3.connect(self.sqlite_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM analytics ORDER BY timestamp ASC LIMIT 100")
        history = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return history

    # ML PREDICTION HISTORY METHODS
    def save_ml_prediction(self, prediction):
        timestamp_str = datetime.utcnow().isoformat()

        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                doc = prediction.copy()
                doc["timestamp"] = datetime.utcnow()
                self.mongo_db.ml_predictions.insert_one(doc)
                return
            except Exception as e:
                print(f"MongoDB ML prediction write failed: {e}. Writing to SQLite.")

        conn = sqlite3.connect(self.sqlite_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO ml_predictions (
                pod_name, namespace, prediction, ml_label, idle_score, cpu_usage,
                memory_usage, network_activity, request_frequency, uptime, restart_count, timestamp
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            prediction.get("pod_name"),
            prediction.get("namespace"),
            prediction.get("prediction"),
            prediction.get("ml_label"),
            prediction.get("idle_score"),
            prediction.get("cpu_usage"),
            prediction.get("memory_usage"),
            prediction.get("network_activity"),
            prediction.get("request_frequency"),
            prediction.get("uptime"),
            prediction.get("restart_count"),
            timestamp_str
        ))
        conn.commit()
        conn.close()

    def get_ml_predictions(self, limit=100):
        if self.db_type == "mongodb" and self.mongo_db is not None:
            try:
                cursor = self.mongo_db.ml_predictions.find().sort("timestamp", -1).limit(limit)
                predictions = []
                for doc in cursor:
                    doc["_id"] = str(doc["_id"])
                    if isinstance(doc.get("timestamp"), datetime):
                        doc["timestamp"] = doc["timestamp"].isoformat()
                    predictions.append(doc)
                return predictions
            except Exception as e:
                print(f"MongoDB ML prediction read failed: {e}. Reading from SQLite.")

        conn = sqlite3.connect(self.sqlite_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ml_predictions ORDER BY timestamp DESC LIMIT ?", (limit,))
        predictions = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return predictions

db = IdlePodDatabase()
