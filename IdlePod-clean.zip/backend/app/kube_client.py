import time
import random
from kubernetes import client, config
from app.utils import convert_cpu_to_millicores, convert_memory_to_mb
from app.config import settings

class KubernetesClient:
    def __init__(self):
        self.v1 = None
        self.custom = None
        self.apps_v1 = None
        self.connected = False
        
        try:
            config.load_kube_config()
            self.v1 = client.CoreV1Api()
            self.custom = client.CustomObjectsApi()
            self.apps_v1 = client.AppsV1Api()
            self.connected = True
            print("Connected to Kubernetes Cluster via Kubeconfig.")
        except Exception as e:
            print(f"Kubernetes cluster connection offline: {e}. Running in SIMULATOR mode.")
            
        # Keep track of simulation uptime state
        self.sim_start_time = time.time()

    def fetch_pods_and_metrics(self):
        """
        Fetches all pods, their requested resources, and their actual usage metrics.
        Returns a list of dicts with all raw parameters.
        """
        if self.connected:
            try:
                return self._fetch_real_cluster()
            except Exception as e:
                print(f"Error fetching real cluster metrics: {e}. Switching to simulator.")
                
        return self._generate_simulated_cluster()

    def fetch_node_utilization(self):
        """Fetch node CPU/memory utilization from metrics-server, or return simulated nodes."""
        if self.connected:
            try:
                nodes = {node.metadata.name: node for node in self.v1.list_node().items}
                metrics = self.custom.list_cluster_custom_object("metrics.k8s.io", "v1beta1", "nodes")
                node_stats = []
                for item in metrics.get("items", []):
                    name = item["metadata"]["name"]
                    usage = item.get("usage", {})
                    cpu_usage_m = convert_cpu_to_millicores(usage.get("cpu", "0m"))
                    memory_usage_mb = convert_memory_to_mb(usage.get("memory", "0Mi"))
                    node = nodes.get(name)
                    capacity = node.status.capacity if node and node.status else {}
                    cpu_capacity_m = convert_cpu_to_millicores(capacity.get("cpu", "0"))
                    memory_capacity_mb = convert_memory_to_mb(capacity.get("memory", "0Ki"))
                    node_stats.append({
                        "node_name": name,
                        "cpu_usage_m": round(cpu_usage_m, 2),
                        "cpu_capacity_m": round(cpu_capacity_m, 2),
                        "cpu_utilization_percent": round((cpu_usage_m / cpu_capacity_m) * 100, 2) if cpu_capacity_m else 0,
                        "memory_usage_mb": round(memory_usage_mb, 2),
                        "memory_capacity_mb": round(memory_capacity_mb, 2),
                        "memory_utilization_percent": round((memory_usage_mb / memory_capacity_mb) * 100, 2) if memory_capacity_mb else 0
                    })
                return node_stats
            except Exception as e:
                print(f"Node metrics query failed: {e}. Returning simulated node utilization.")

        return [{
            "node_name": "simulated-node-1",
            "cpu_usage_m": 520.0,
            "cpu_capacity_m": 4000.0,
            "cpu_utilization_percent": 13.0,
            "memory_usage_mb": 1536.0,
            "memory_capacity_mb": 8192.0,
            "memory_utilization_percent": 18.75
        }]

    def _fetch_real_cluster(self):
        pods_info = []
        
        # 1. Fetch Pod specifications from CoreV1Api
        pod_list = self.v1.list_pod_for_all_namespaces(watch=False)
        
        # 2. Fetch Pod metrics from CustomObjectsApi (metrics.k8s.io)
        metrics_map = {}
        try:
            metrics = self.custom.list_cluster_custom_object("metrics.k8s.io", "v1beta1", "pods")
            for pod in metrics.get('items', []):
                name = pod['metadata']['name']
                ns = pod['metadata']['namespace']
                
                # Sum metrics for all containers
                cpu_m = 0
                mem_mb = 0.0
                for container in pod.get('containers', []):
                    usage = container.get('usage', {})
                    cpu_m += convert_cpu_to_millicores(usage.get('cpu', '0m'))
                    mem_mb += convert_memory_to_mb(usage.get('memory', '0Mi'))
                metrics_map[(name, ns)] = (cpu_m, round(mem_mb, 2))
        except Exception as e:
            print(f"Metrics-server query failed: {e}. Using simulated metrics for active pods.")
            
        # 3. Assemble pod resources + metrics
        for pod in pod_list.items:
            name = pod.metadata.name
            ns = pod.metadata.namespace
            if ns in settings.PROTECTED_NAMESPACES:
                continue

            status = pod.status.phase
            owner = self._resolve_workload_owner(pod)
            node_name = pod.spec.node_name if pod.spec else None
            
            # Sum up CPU/Memory Requests
            cpu_req_millicores = 0
            mem_req_mb = 0.0
            cpu_req_str = "0m"
            mem_req_str = "0Mi"
            
            if pod.spec and pod.spec.containers:
                for container in pod.spec.containers:
                    if container.resources and container.resources.requests:
                        r = container.resources.requests
                        if 'cpu' in r:
                            cpu_req_str = r['cpu']
                            cpu_req_millicores += convert_cpu_to_millicores(r['cpu'])
                        if 'memory' in r:
                            mem_req_str = r['memory']
                            mem_req_mb += convert_memory_to_mb(r['memory'])
            
            # Fetch actual metrics
            usage_cpu = 0.0
            usage_mem = 0.0
            if (name, ns) in metrics_map:
                usage_cpu, usage_mem = metrics_map[(name, ns)]
            else:
                # If running, generate some small realistic metric usage to prevent N/A errors
                if status == "Running":
                    usage_cpu = random.uniform(1.0, 10.0) if "idle" in name else random.uniform(20.0, 120.0)
                    usage_mem = random.uniform(10.0, 50.0) if "idle" in name else random.uniform(100.0, 300.0)
            
            # Calculate pod uptime
            uptime_min = 0
            if pod.status.start_time:
                uptime_min = int((time.time() - pod.status.start_time.timestamp()) / 60)
            
            # Sum container restarts
            restarts = 0
            if pod.status.container_statuses:
                for c_status in pod.status.container_statuses:
                    restarts += c_status.restart_count
                    
            # Generate simulated network activity (requests/sec)
            network = 0.0
            if status == "Running":
                network = 0.1 if "idle" in name else round(random.uniform(5.0, 50.0), 2)
            request_frequency = network
            
            pods_info.append({
                "pod_name": name,
                "namespace": ns,
                "node_name": node_name,
                "status": status,
                "cpu_requested": cpu_req_str,
                "memory_requested": mem_req_str,
                "cpu_usage": usage_cpu,
                "memory_usage": usage_mem,
                "network_activity": network,
                "request_frequency": request_frequency,
                "restart_count": restarts,
                "uptime": uptime_min,
                "workload_name": owner["workload_name"],
                "workload_kind": owner["workload_kind"],
                "replica_count": owner["replica_count"]
            })
            
        return pods_info

    def resolve_workload_for_pod(self, pod_name, namespace):
        """Resolve the owning Kubernetes workload for a pod using owner references."""
        if namespace in settings.PROTECTED_NAMESPACES:
            return {
                "workload_name": pod_name,
                "workload_kind": "ProtectedNamespace",
                "replica_count": 0
            }

        if not self.connected:
            return {
                "workload_name": self._parse_deployment_name(pod_name),
                "workload_kind": "Deployment",
                "replica_count": 1
            }

        try:
            pod = self.v1.read_namespaced_pod(pod_name, namespace)
            return self._resolve_workload_owner(pod)
        except Exception as e:
            print(f"Failed to resolve workload owner for pod {pod_name}: {e}")
            return {
                "workload_name": self._parse_deployment_name(pod_name),
                "workload_kind": "Unknown",
                "replica_count": 0
            }

    def _resolve_workload_owner(self, pod):
        """Walk pod -> ReplicaSet -> Deployment ownership instead of parsing pod names."""
        pod_name = pod.metadata.name
        namespace = pod.metadata.namespace
        owner_refs = pod.metadata.owner_references or []

        for owner in owner_refs:
            if owner.kind == "ReplicaSet":
                try:
                    replica_set = self.apps_v1.read_namespaced_replica_set(owner.name, namespace)
                    rs_owner_refs = replica_set.metadata.owner_references or []
                    for rs_owner in rs_owner_refs:
                        if rs_owner.kind == "Deployment":
                            deployment = self.apps_v1.read_namespaced_deployment(rs_owner.name, namespace)
                            return {
                                "workload_name": rs_owner.name,
                                "workload_kind": "Deployment",
                                "replica_count": deployment.spec.replicas or 0
                            }

                    return {
                        "workload_name": owner.name,
                        "workload_kind": "ReplicaSet",
                        "replica_count": replica_set.spec.replicas or 0
                    }
                except Exception as e:
                    print(f"Failed resolving ReplicaSet owner for pod {pod_name}: {e}")

            return {
                "workload_name": owner.name,
                "workload_kind": owner.kind,
                "replica_count": 0
            }

        return {
            "workload_name": pod_name,
            "workload_kind": "Pod",
            "replica_count": 1
        }

    def _parse_deployment_name(self, pod_name):
        parts = pod_name.split('-')
        if len(parts) >= 3:
            return "-".join(parts[:-2])
        return pod_name

    def _generate_simulated_cluster(self):
        """Generates mock pods simulating active, idle, and bursty workloads in multiple namespaces."""
        pods_info = []
        
        # 3 mock namespaces
        namespaces = ["production", "development", "testing"]
        
        # Fixed workload specs: Name prefix, Namespace, CPU req, Mem req, Type (active, idle, bursty)
        workloads = [
            # Production - Active
            ("frontend-service-prod-7b89", "production", "500m", "512Mi", "active"),
            ("auth-api-prod-d4e5", "production", "200m", "256Mi", "active"),
            ("order-processor-prod-a2b3", "production", "1000m", "1024Mi", "active"),
            # Production - Idle (Over-provisioned)
            ("jenkins-agent-idle-01", "production", "2000m", "4096Mi", "idle"),
            ("log-shipper-debug-02", "production", "400m", "512Mi", "idle"),
            
            # Development - Underutilized / Idle
            ("nginx-test-dev-12", "development", "200m", "256Mi", "idle"),
            ("grafana-dashboard-dev-c7", "development", "500m", "1024Mi", "idle"),
            ("mysql-dev-instance", "development", "1000m", "2048Mi", "idle"),
            # Development - Active
            ("redis-cache-dev-bb", "development", "100m", "128Mi", "active"),
            
            # Testing - Bursty (changes behavior over time)
            ("batch-report-cron-tester", "testing", "800m", "1024Mi", "bursty"),
            ("selenium-node-idle-99", "testing", "1500m", "2048Mi", "idle")
        ]
        
        # Compute dynamic simulation parameters based on time
        seconds_active = int(time.time() - self.sim_start_time)
        cycle = (seconds_active // 30) % 2 # Bursty workload alternates every 30s
        
        for name, ns, cpu_req, mem_req, wl_type in workloads:
            # CPU conversion to float millicores
            cpu_req_m = convert_cpu_to_millicores(cpu_req)
            mem_req_mb = convert_memory_to_mb(mem_req)
            
            restarts = 0
            status = "Running"
            
            # Generate resource usages based on type
            if wl_type == "active":
                # Uses 40% - 85% of requested resources
                usage_cpu = round(cpu_req_m * random.uniform(0.40, 0.85), 2)
                usage_mem = round(mem_req_mb * random.uniform(0.50, 0.80), 2)
                network = round(random.uniform(15.0, 80.0), 2)
                uptime = int(seconds_active / 60) + 1200 # Up for 20 hours
            elif wl_type == "idle":
                # Uses 0.5% - 4% of requested resources (wasting heavy resources)
                usage_cpu = round(cpu_req_m * random.uniform(0.005, 0.03), 2)
                usage_mem = round(mem_req_mb * random.uniform(0.01, 0.04), 2)
                network = round(random.uniform(0.0, 0.8), 2)
                uptime = int(seconds_active / 60) + 480 # Up for 8 hours
            else: # bursty
                if cycle == 0: # Idle phase
                    usage_cpu = round(cpu_req_m * random.uniform(0.01, 0.05), 2)
                    usage_mem = round(mem_req_mb * random.uniform(0.05, 0.10), 2)
                    network = 0.2
                else: # Active phase
                    usage_cpu = round(cpu_req_m * random.uniform(0.60, 0.90), 2)
                    usage_mem = round(mem_req_mb * random.uniform(0.50, 0.75), 2)
                    network = round(random.uniform(40.0, 120.0), 2)
                uptime = int(seconds_active / 60) + 30
            
            # Inject a crashing pod (high restarts)
            if "nginx-test-dev" in name:
                restarts = int(seconds_active / 40) % 5
                
            pods_info.append({
                "pod_name": name,
                "namespace": ns,
                "node_name": "simulated-node-1",
                "status": status,
                "cpu_requested": cpu_req,
                "memory_requested": mem_req,
                "cpu_usage": usage_cpu,
                "memory_usage": usage_mem,
                "network_activity": network,
                "request_frequency": network,
                "restart_count": restarts,
                "uptime": uptime,
                "workload_name": self._parse_deployment_name(name),
                "workload_kind": "Deployment",
                "replica_count": 1
            })
            
        return pods_info

kube_client = KubernetesClient()
