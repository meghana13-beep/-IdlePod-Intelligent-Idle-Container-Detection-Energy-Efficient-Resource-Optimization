from kubernetes import client
from app.kube_client import kube_client
from app.database import db
from app.config import settings

class OptimizationEngine:
    def __init__(self):
        # Modes: "simulation", "manual", "automatic"
        self.mode = "simulation"

    def set_mode(self, mode):
        if mode in ["simulation", "manual", "automatic"]:
            self.mode = mode
            return True
        return False

    def generate_recommendation(self, pod):
        """Generates scale-down recommendations based on idle score."""
        pod_name = pod.get("pod_name")
        ns = pod.get("namespace")
        idle_score = pod.get("idle_score", 0)
        
        deployment_name = pod.get("workload_name") or self._parse_deployment_name(pod_name)
        workload_kind = pod.get("workload_kind", "Deployment")
        
        action = "Scale Down"
        details = "Reduce replicas to 1"
        priority = "Medium"
        
        if idle_score >= 85:
            priority = "High"
            details = "Reduce replicas to 1 (or 0 if non-critical)"
        
        return {
            "pod_name": pod_name,
            "namespace": ns,
            "deployment_name": deployment_name,
            "workload_kind": workload_kind,
            "recommendation": f"{action} - {details}",
            "idle_score": idle_score,
            "priority": priority,
            "status": "Pending Approval" if self.mode == "manual" else "Auto-Triggered" if self.mode == "automatic" else "Simulation Mode"
        }

    def execute_optimization(self, pod_name, namespace, action_type="Scale Down"):
        """
        Executes scale-down or delete operation on Kubernetes.
        If cluster is not connected or in Simulation mode, it executes simulated scaling.
        """
        owner = kube_client.resolve_workload_for_pod(pod_name, namespace)
        deployment_name = owner["workload_name"]
        workload_kind = owner["workload_kind"]
        resources_saved = "250m CPU, 128Mi Memory"  # Estimated savings baseline
        status = "Completed"

        if namespace in settings.PROTECTED_NAMESPACES:
            action_detail = f"Skipped optimization for protected namespace '{namespace}'"
            status = "Skipped - Protected Namespace"
            resources_saved = "0"
            record = {
                "pod_name": pod_name,
                "namespace": namespace,
                "action_taken": action_detail,
                "resources_saved": resources_saved,
                "optimization_status": status
            }
            db.save_optimization(record)
            db.save_alert({
                "alert_type": "OptimizationSkipped",
                "severity": "Warning",
                "message": f"Action skipped for {pod_name}: namespace {namespace} is protected."
            })
            return record
        
        # Real cluster scaling execution
        if kube_client.connected and self.mode != "simulation":
            try:
                apps_v1 = client.AppsV1Api()
                autoscaling_v1 = client.AutoscalingV1Api()
                skip = False
                
                # 1. Check workload type - StatefulSet
                try:
                    stateful_sets = apps_v1.list_namespaced_stateful_set(namespace)
                    if any(sts.metadata.name == deployment_name for sts in stateful_sets.items):
                        status = "Skipped - Unsafe Workload Type (StatefulSet/DaemonSet)"
                        skip = True
                except Exception as e:
                    print(f"Error checking StatefulSets: {e}")

                if not skip:
                    # 1. Check workload type - DaemonSet
                    try:
                        daemon_sets = apps_v1.list_namespaced_daemon_set(namespace)
                        if any(ds.metadata.name == deployment_name for ds in daemon_sets.items):
                            status = "Skipped - Unsafe Workload Type (StatefulSet/DaemonSet)"
                            skip = True
                    except Exception as e:
                        print(f"Error checking DaemonSets: {e}")

                if not skip:
                    # 2. Check for existing HPA
                    try:
                        hpas = autoscaling_v1.list_namespaced_horizontal_pod_autoscaler(namespace)
                        if any(hpa.spec.scale_target_ref.name == deployment_name for hpa in hpas.items):
                            status = "Skipped - HPA Managed (manual scaling would conflict)"
                            skip = True
                    except Exception as e:
                        print(f"Error checking HPAs: {e}")

                if skip:
                    action_detail = f"Skipped scaling for '{deployment_name}'"
                    resources_saved = "0"
                elif workload_kind != "Deployment":
                    status = f"Skipped - Unsupported Workload Type ({workload_kind})"
                    action_detail = f"Skipped scaling for '{deployment_name}'"
                    resources_saved = "0"
                else:
                    # Check if deployment exists
                    deployments = apps_v1.list_namespaced_deployment(namespace)
                    matching_dep = None
                    for dep in deployments.items:
                        if dep.metadata.name == deployment_name:
                            matching_dep = dep
                            break
                    
                    if matching_dep:
                        # 3. Check current replica count
                        if matching_dep.spec.replicas <= 1:
                            status = "Skipped - Already at minimum replicas"
                            action_detail = f"Skipped scaling for '{deployment_name}'"
                            resources_saved = "0"
                        else:
                            # 4. Scale to max(1, current_replicas - 1)
                            target_replicas = max(1, matching_dep.spec.replicas - 1)
                            body = {"spec": {"replicas": target_replicas}}
                            apps_v1.patch_namespaced_deployment_scale(deployment_name, namespace, body)
                            action_detail = f"Scaled deployment '{deployment_name}' replicas to {target_replicas}"
                            
                            # Estimate savings from deployment spec
                            cpu_lim = "0"
                            mem_lim = "0"
                            if matching_dep.spec.template.spec.containers:
                                c = matching_dep.spec.template.spec.containers[0]
                                if c.resources and c.resources.requests:
                                    cpu_lim = c.resources.requests.get("cpu", "250m")
                                    mem_lim = c.resources.requests.get("memory", "128Mi")
                            resources_saved = f"{cpu_lim} CPU, {mem_lim} Memory"
                    else:
                        # If it's a standalone pod (not a deployment), we can delete it
                        v1_api = client.CoreV1Api()
                        v1_api.delete_namespaced_pod(pod_name, namespace)
                        action_detail = f"Deleted standalone pod '{pod_name}'"
            except Exception as e:
                print(f"Error executing real Kubernetes optimization: {e}")
                action_detail = f"Failed to scale {pod_name}: {e}"
                status = "Failed"
        else:
            # Simulated scaling
            action_detail = f"Scaled deployment '{deployment_name}' to 1 replica (Simulated)"
            status = "Simulated"

        # Log to Database
        record = {
            "pod_name": pod_name,
            "namespace": namespace,
            "action_taken": action_detail,
            "resources_saved": resources_saved,
            "optimization_status": status
        }
        db.save_optimization(record)
        
        # Add warning/alert log
        db.save_alert({
            "alert_type": "OptimizationTriggered",
            "severity": "Info",
            "message": f"Action Executed: {action_detail} in namespace {namespace}. Status: {status}."
        })
        
        return record

    def _parse_deployment_name(self, pod_name):
        # Extract deployment name: pod-name-replicaset-hash -> pod-name
        parts = pod_name.split('-')
        if len(parts) >= 3:
            # Typically standard k8s deployments add two random hashes at the end
            return "-".join(parts[:-2])
        return pod_name

optimization_engine = OptimizationEngine()
