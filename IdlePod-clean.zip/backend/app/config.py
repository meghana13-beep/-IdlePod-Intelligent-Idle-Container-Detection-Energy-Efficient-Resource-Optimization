import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # App General Config
    APP_ENV: str = "development"
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000"
    JWT_SECRET_KEY: str = "change-this-idlepod-demo-secret"
    JWT_EXPIRY_MINUTES: int = 120
    ADMIN_USERNAME: str = "admin"
    ADMIN_PASSWORD: str = "IdlePodAdmin2026"
    REFRESH_INTERVAL: int = 5
    DB_TYPE: str = "sqlite" # sqlite, mongodb
    DATABASE_URL: str = "sqlite:///./idlepod.db"
    MONGODB_URI: str = "mongodb://localhost:27017"
    MONGODB_DB: str = "idlepod"
    
    # Idle Threshold defaults (will be updated dynamically)
    DEFAULT_CPU_THRESHOLD_M: int = 50       # millicores
    DEFAULT_MEM_THRESHOLD_MB: float = 50.0   # Megabytes
    IDLE_CHECKS_REQUIRED: int = 2           # number of cycles under thresholds to flag as idle
    
    # AWS Simulation & Credentials
    AWS_SIMULATE: bool = True               # Runs AWS operations locally without boto3 errors
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION: str = "us-east-1"
    SNS_TOPIC_ARN: str = "arn:aws:sns:us-east-1:123456789012:IdlePodAlerts"
    S3_BUCKET_NAME: str = "idlepod-optimization-reports"
    LAMBDA_FUNCTION_NAME: str = "IdlePodScaleDownExecutor"
    CLOUDWATCH_NAMESPACE: str = "IdlePodMetrics"
    COST_EXPLORER_LOOKBACK_DAYS: int = 14
    PROTECTED_NAMESPACES: list[str] = ["kube-system", "kube-public", "kube-node-lease"]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
