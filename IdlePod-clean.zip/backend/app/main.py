import os
import sys
import asyncio
import threading

# Add the backend folder to sys.path so 'app' can be found
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# pyrefly: ignore [missing-import]
from fastapi import Depends, FastAPI, BackgroundTasks, HTTPException
# pyrefly: ignore [missing-import]
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict
from datetime import datetime

from app.config import settings
from app.database import db
from app.kube_client import kube_client
from app.threshold_engine import threshold_engine
from app.heuristic_engine import heuristic_engine
from app.ml_engine import ml_engine
from app.optimization_engine import optimization_engine
from app.analytics_engine import analytics_engine
from app.aws_client import aws_client
from app.security import LoginRequest, authenticate_user, create_access_token, require_auth

app = FastAPI(
    title="IdlePod: Intelligent Idle Container Detection API",
    description="Backend API powering green cloud-native Kubernetes optimization",
    version="2.0.0"
)

# Enable CORS for React Frontend communication
cors_origins = [origin.strip() for origin in settings.CORS_ORIGINS.split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Track server states
monitor_running = True
background_thread = None
last_run_timestamp = "Never"

async def monitor_loop():
    """
    Background loops that regularly reads Kubernetes data, evaluates thresholds,
    runs the heuristic and ML algorithms, and pushes alerts / savings records.
    """
    global last_run_timestamp
    print("Background monitoring thread started.")
    
    cycle_count = 0
    while monitor_running:
        try:
            print("--- Executing IdlePod optimization check cycle ---")
            # 1. Fetch Pod specifications and live CPU/Mem usage
            raw_pods = kube_client.fetch_pods_and_metrics()
            if not raw_pods:
                print("No pods found or failed to fetch cluster.")
                await asyncio.sleep(settings.REFRESH_INTERVAL)
                continue
            
            # Map of namespaces present
            namespaces = set(p['namespace'] for p in raw_pods)
            
            # 2. Compute dynamic thresholds per namespace
            ns_thresholds = {}
            for ns in namespaces:
                cpu_t, mem_t = threshold_engine.update_and_get_thresholds(raw_pods, ns)
                ns_thresholds[ns] = {"cpu": cpu_t, "mem": mem_t}
            
            # 3. Score pods via heuristics & validate via ML
            processed_pods = []
            for pod in raw_pods:
                ns = pod['namespace']
                thresh = ns_thresholds[ns]
                
                # Heuristic scoring
                score, status, priority = heuristic_engine.calculate_idle_score(pod, thresh["cpu"], thresh["mem"])
                
                # ML Anomaly verification
                ml_pred = ml_engine.predict_anomaly(pod)
                ml_label = "Suspicious Idle" if ml_pred == "Anomaly" else "Active Pattern"
                
                # Assemble record
                p_record = pod.copy()
                p_record["idle_score"] = score
                p_record["status"] = status
                p_record["ml_prediction"] = ml_pred
                p_record["ml_label"] = ml_label
                processed_pods.append(p_record)
                db.save_ml_prediction({
                    "pod_name": pod["pod_name"],
                    "namespace": pod["namespace"],
                    "prediction": ml_pred,
                    "ml_label": ml_label,
                    "idle_score": score,
                    "cpu_usage": pod.get("cpu_usage", 0),
                    "memory_usage": pod.get("memory_usage", 0),
                    "network_activity": pod.get("network_activity", 0),
                    "request_frequency": pod.get("request_frequency", pod.get("network_activity", 0)),
                    "uptime": pod.get("uptime", 0),
                    "restart_count": pod.get("restart_count", 0)
                })

            # 4. Save snapshots to Database
            db.save_pod_metrics(processed_pods)
            last_run_timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

            # 5. Process optimizations & alerts
            idle_pod_count = len([pod for pod in processed_pods if pod.get("status") == "Idle"])
            underutilized_count = len([pod for pod in processed_pods if pod.get("status") == "Underutilized"])
            aws_client.push_metric(
                name="IdlePodCount",
                value=idle_pod_count,
                unit="Count",
                dimensions=[
                    {"Name": "Cluster", "Value": "IdlePodDemo"}
                ]
            )
            aws_client.push_metric(
                name="UnderutilizedPodCount",
                value=underutilized_count,
                unit="Count",
                dimensions=[
                    {"Name": "Cluster", "Value": "IdlePodDemo"}
                ]
            )

            for pod in processed_pods:
                if pod["status"] == "Idle":
                    # Generate AWS CloudWatch custom metric log
                    aws_client.push_metric(
                        name="IdleConfidenceScore",
                        value=pod["idle_score"],
                        unit="Percent",
                        dimensions=[
                            {"Name": "PodName", "Value": pod["pod_name"]},
                            {"Name": "Namespace", "Value": pod["namespace"]}
                        ]
                    )
                    
                    # SNS Alerts for High-Confidence Idle pods
                    if pod["idle_score"] >= 80:
                        alert_msg = (
                            f"IdlePod Alert: Highly underutilized pod detected!\n"
                            f"Pod Name: {pod['pod_name']}\n"
                            f"Namespace: {pod['namespace']}\n"
                            f"CPU Requested: {pod['cpu_requested']} | CPU Usage: {pod['cpu_usage']}m\n"
                            f"Heuristic Idle Confidence: {pod['idle_score']}% | ML Classification: {pod['ml_prediction']}\n"
                            f"Please approve scale-down inside the Optimization Center."
                        )
                        # Avoid flooding; trigger SNS alert only on critical thresholds
                        aws_client.send_notification(
                            subject=f"CRITICAL: Idle Pod Detected [{pod['pod_name']}]",
                            message=alert_msg
                        )
                        
                        # Save Alert to DB log
                        db.save_alert({
                            "alert_type": "IdlePodDetected",
                            "severity": "Warning",
                            "message": f"Pod {pod['pod_name']} in namespace {pod['namespace']} is idling (Score: {pod['idle_score']}%)"
                        })
                    
                    # 6. Automatic Optimization Execution
                    if optimization_engine.mode == "automatic":
                        print(f"AUTO OPTIMIZATION: Triggering scale down for {pod['pod_name']}")
                        # Trigger Lambda simulation and perform scale
                        aws_client.trigger_lambda_optimization({
                            "pod_name": pod["pod_name"],
                            "namespace": pod["namespace"],
                            "action": "ScaleDown"
                        })
                        optimization_engine.execute_optimization(pod["pod_name"], pod["namespace"])
            
            # 7. Generate Energy Analytics
            analytics_engine.calculate_savings()
            
            # 8. S3 Reporting simulation (upload CSV logs every 10 iterations)
            cycle_count += 1
            if cycle_count >= 10:
                cycle_count = 0
                aws_client.upload_report_to_s3(f"report-{int(datetime.utcnow().timestamp())}.csv", processed_pods)
                print("Uploaded monitoring telemetry report to AWS S3.")
                
        except Exception as e:
            print(f"Exception in monitoring thread loop: {e}")
            
        await asyncio.sleep(settings.REFRESH_INTERVAL)

def start_background_loop():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(monitor_loop())

@app.on_event("startup")
async def startup_event():
    global background_thread
    background_thread = threading.Thread(target=start_background_loop, daemon=True)
    background_thread.start()
    # Fit initial ML model
    ml_engine.train_model()

@app.on_event("shutdown")
def shutdown_event():
    global monitor_running
    monitor_running = False

# REST API ENDPOINTS

@app.post("/auth/login")
def login(credentials: LoginRequest):
    """Issue a short-lived bearer token for protected operator actions."""
    if not authenticate_user(credentials.username, credentials.password):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return {
        "access_token": create_access_token(credentials.username),
        "token_type": "bearer",
        "expires_in_minutes": settings.JWT_EXPIRY_MINUTES
    }

@app.get("/")
def read_root():
    return {
        "status": "online",
        "timestamp": datetime.utcnow(),
        "mode": optimization_engine.mode,
        "last_refresh": last_run_timestamp,
        "k8s_connected": kube_client.connected,
        "aws_simulated": aws_client.simulate
    }

@app.get("/config")
def get_frontend_config():
    """Returns frontend-safe config values from backend settings."""
    return {
        "cpu_threshold_m": settings.DEFAULT_CPU_THRESHOLD_M,
        "mem_threshold_mb": settings.DEFAULT_MEM_THRESHOLD_MB,
        "idle_checks_required": settings.IDLE_CHECKS_REQUIRED,
        "refresh_interval": settings.REFRESH_INTERVAL
    }

@app.get("/pods")
def get_all_pods():
    """Retrieve the latest monitored pod snapshots."""
    return db.get_latest_pod_metrics()

@app.get("/metrics")
def get_metrics():
    """Prompt-compatible combined metrics endpoint for pods and nodes."""
    return {
        "pods": db.get_latest_pod_metrics(),
        "nodes": kube_client.fetch_node_utilization(),
        "cluster_health": get_cluster_health()
    }

@app.get("/idlepods")
def get_idle_pods():
    """Retrieve pods flagged as Underutilized or Idle."""
    all_pods = db.get_latest_pod_metrics()
    return [p for p in all_pods if p.get("status") in ["Idle", "Underutilized"]]

@app.get("/cluster-health")
def get_cluster_health():
    """Aggregates pod details into a single cluster health response."""
    pods = db.get_latest_pod_metrics()
    if not pods:
        return {
            "total_pods": 0, "active_pods": 0, "idle_pods": 0, 
            "underutilized_pods": 0, "efficiency_score": 100
        }
        
    total = len(pods)
    idle = len([p for p in pods if p.get("status") == "Idle"])
    under = len([p for p in pods if p.get("status") == "Underutilized"])
    active = total - idle - under
    
    # Simple efficiency score (more idle pods = lower efficiency)
    efficiency = max(0, min(100, int((active + (under * 0.5)) / total * 100)))
    
    return {
        "total_pods": total,
        "active_pods": active,
        "idle_pods": idle,
        "underutilized_pods": under,
        "efficiency_score": efficiency
    }

@app.post("/optimize")
def post_optimize(pod_name: str, namespace: str, action: str = "Scale Down", _user: str = Depends(require_auth)):
    """Manually triggers optimization scale down for a specific pod."""
    try:
        result = optimization_engine.execute_optimization(pod_name, namespace, action)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/scale-down")
def post_scale_down(pod_name: str, namespace: str, _user: str = Depends(require_auth)):
    """Prompt-compatible alias for manual scale-down optimization."""
    return post_optimize(pod_name=pod_name, namespace=namespace, action="Scale Down", _user=_user)

@app.post("/cleanup")
def post_cleanup(namespace: str = "all", _user: str = Depends(require_auth)):
    """Safe cleanup workflow placeholder that records cleanup recommendations without deleting resources."""
    pods = db.get_latest_pod_metrics()
    candidates = [
        pod for pod in pods
        if pod.get("status") == "Idle" and (namespace == "all" or pod.get("namespace") == namespace)
    ]
    record = {
        "pod_name": f"{len(candidates)} idle cleanup candidates",
        "namespace": namespace,
        "action_taken": "Generated safe cleanup recommendation report",
        "resources_saved": "Pending operator approval",
        "optimization_status": "Simulated"
    }
    db.save_optimization(record)
    db.save_alert({
        "alert_type": "CleanupRecommendation",
        "severity": "Info",
        "message": f"Cleanup scan found {len(candidates)} idle pod candidates in namespace scope '{namespace}'."
    })
    return {"status": "success", "candidate_count": len(candidates), "candidates": candidates}

@app.get("/optimization/recommendations")
def get_recommendations():
    """Generates a list of current scale-down recommendations."""
    idle_pods = [p for p in db.get_latest_pod_metrics() if p.get("status") in ["Idle", "Underutilized"]]
    recommendations = []
    for pod in idle_pods:
        recs = optimization_engine.generate_recommendation(pod)
        recommendations.append(recs)
    return recommendations

@app.get("/optimization/history")
def get_optimization_history():
    """Get history of completed optimizations."""
    return db.get_optimizations()

@app.post("/optimization/mode")
def set_optimization_mode(mode: str, _user: str = Depends(require_auth)):
    """Update optimization mode: simulation, manual, automatic."""
    success = optimization_engine.set_mode(mode)
    if not success:
        raise HTTPException(status_code=400, detail="Invalid mode. Choose: simulation, manual, automatic")
    return {"status": "success", "current_mode": optimization_engine.mode}

@app.get("/analytics/savings")
def get_energy_savings():
    """Returns cost reduction and power offset analytics."""
    return analytics_engine.calculate_savings()

@app.get("/analytics")
def get_analytics():
    """Prompt-compatible analytics summary endpoint."""
    return {
        "savings": analytics_engine.calculate_savings(),
        "history": db.get_analytics_history()
    }

@app.get("/energy-savings")
def get_energy_savings_alias():
    """Prompt-compatible alias for energy savings analytics."""
    return get_energy_savings()

@app.get("/analytics/history")
def get_analytics_history():
    """Returns historical records of savings updates for graphing trends."""
    return db.get_analytics_history()

@app.get("/utilization-trends")
def get_utilization_trends():
    """Prompt-compatible trend endpoint combining analytics history with current node utilization."""
    return {
        "analytics_history": db.get_analytics_history(),
        "node_utilization": kube_client.fetch_node_utilization()
    }

@app.get("/ml/predictions")
def get_ml_prediction_history(limit: int = 100):
    """Returns recent ML validation results for audit and demo proof."""
    safe_limit = max(1, min(limit, 500))
    return db.get_ml_predictions(safe_limit)

@app.get("/alerts")
def get_active_alerts():
    """Fetch recent resource alerts and event messages."""
    return db.get_alerts()

@app.get("/aws/logs")
def get_aws_actions():
    """Retrieve simulated AWS action records (CloudWatch, SNS, S3, Lambda)."""
    return aws_client.get_simulation_logs()

@app.get("/aws/costs")
def get_aws_costs(days: int = settings.COST_EXPLORER_LOOKBACK_DAYS):
    """Fetch real AWS daily billing data from Cost Explorer for analytics."""
    safe_days = max(1, min(days, 31))
    savings = analytics_engine.calculate_savings()
    costs = aws_client.get_daily_costs(safe_days)
    total_cost = costs.get("total_cost_usd", 0) or 0
    estimated_saved = savings.get("cumulative_cost_saved_usd", 0) or 0
    offset_percent = round((estimated_saved / total_cost) * 100, 2) if total_cost > 0 else 0.0
    return {
        **costs,
        "estimated_savings_usd": estimated_saved,
        "estimated_savings_vs_real_spend_percent": offset_percent,
        "lookback_days": safe_days
    }

@app.post("/aws/send-alert")
def send_manual_sns_alert(subject: str, message: str, _user: str = Depends(require_auth)):
    """Direct SNS alert notification post."""
    success = aws_client.send_notification(subject, message)
    if success:
        return {"status": "success", "message": "SNS notification pushed."}
    raise HTTPException(status_code=500, detail="Failed to publish SNS alert.")

@app.post("/send-alert")
def send_alert_alias(subject: str, message: str, _user: str = Depends(require_auth)):
    """Prompt-compatible alias for AWS SNS alert publishing."""
    return send_manual_sns_alert(subject=subject, message=message, _user=_user)

@app.post("/aws/upload-logs")
def upload_logs_s3(_user: str = Depends(require_auth)):
    """Triggers S3 export of latest pod statistics."""
    pods = db.get_latest_pod_metrics()
    success = aws_client.upload_report_to_s3(f"manual-report-{int(datetime.utcnow().timestamp())}.csv", pods)
    if success:
        return {"status": "success", "message": "Report uploaded to AWS S3 bucket."}
    raise HTTPException(status_code=500, detail="Failed to upload CSV to S3.")

@app.post("/upload-logs")
def upload_logs_alias(_user: str = Depends(require_auth)):
    """Prompt-compatible alias for S3 report upload."""
    return upload_logs_s3(_user=_user)

if __name__ == "__main__":
    # pyrefly: ignore [missing-import]
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
