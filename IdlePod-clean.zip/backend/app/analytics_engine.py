from app.database import db
from app.utils import convert_cpu_to_millicores, convert_memory_to_mb
from app.kube_client import kube_client

class AnalyticsEngine:
    def __init__(self):
        # AWS pricing parameters (simulate t3.medium / m5.large rates)
        # $0.046 per vCPU Hour, $0.006 per GB Hour of memory
        self.usd_per_vcpu_hour = 0.046
        self.usd_per_gb_hour = 0.006
        
        # Energy factors
        # 1 vCPU (1000m) consumes approx 10 Watts under typical virtualization host profiles
        # 1 GB of RAM consumes approx 0.38 Watts
        self.watts_per_vcpu = 10.0
        self.watts_per_gb = 0.38
        
        # Carbon intensity factor: 1 kWh of cloud energy offset ~ 385g CO2
        self.co2_g_per_kwh = 385.0

    def _node_power_factor(self):
        """Adjust vCPU watts using current node utilization when available."""
        nodes = kube_client.fetch_node_utilization()
        if not nodes:
            return self.watts_per_vcpu, 0.0

        avg_cpu_util = sum(n.get("cpu_utilization_percent", 0) for n in nodes) / len(nodes)
        # Idle node share plus dynamic CPU draw. This remains an estimate, but now follows live node load.
        adjusted_watts_per_vcpu = 6.0 + (avg_cpu_util / 100.0 * 8.0)
        return adjusted_watts_per_vcpu, round(avg_cpu_util, 2)

    def _calculate_current_waste_profile(self):
        """
        Estimate current waste using latest pod requests, actual usage, node utilization,
        and pod uptime. This gives a before/after view even before optimizations run.
        """
        pods = db.get_latest_pod_metrics()
        watts_per_vcpu, avg_node_cpu_util = self._node_power_factor()

        before_power_watts = 0.0
        after_power_watts = 0.0
        runtime_weighted_kwh_saved = 0.0
        request_cpu_m = 0.0
        actual_cpu_m = 0.0
        request_mem_mb = 0.0
        actual_mem_mb = 0.0
        evaluated_pods = 0

        for pod in pods:
            if pod.get("status") not in ["Idle", "Underutilized"]:
                continue

            requested_cpu_m = convert_cpu_to_millicores(pod.get("cpu_requested", "0m"))
            requested_mem_mb = convert_memory_to_mb(pod.get("memory_requested", "0Mi"))
            used_cpu_m = float(pod.get("cpu_usage") or 0)
            used_mem_mb = float(pod.get("memory_usage") or 0)
            uptime_hours = max(1.0 / 60.0, min(720.0, float(pod.get("uptime") or 0) / 60.0))

            pod_before_watts = ((requested_cpu_m / 1000.0) * watts_per_vcpu) + ((requested_mem_mb / 1024.0) * self.watts_per_gb)
            pod_after_watts = ((used_cpu_m / 1000.0) * watts_per_vcpu) + ((used_mem_mb / 1024.0) * self.watts_per_gb)
            pod_saved_watts = max(0.0, pod_before_watts - pod_after_watts)

            before_power_watts += pod_before_watts
            after_power_watts += pod_after_watts
            runtime_weighted_kwh_saved += (pod_saved_watts * uptime_hours) / 1000.0
            request_cpu_m += requested_cpu_m
            actual_cpu_m += used_cpu_m
            request_mem_mb += requested_mem_mb
            actual_mem_mb += used_mem_mb
            evaluated_pods += 1

        power_reduction_watts = max(0.0, before_power_watts - after_power_watts)
        return {
            "evaluated_pods": evaluated_pods,
            "node_cpu_utilization_percent": avg_node_cpu_util,
            "watts_per_vcpu_effective": round(watts_per_vcpu, 2),
            "before_power_watts": round(before_power_watts, 2),
            "after_power_watts": round(after_power_watts, 2),
            "estimated_power_reduction_watts": round(power_reduction_watts, 2),
            "runtime_weighted_kwh_saved": round(runtime_weighted_kwh_saved, 4),
            "requested_cpu_m": round(request_cpu_m, 2),
            "actual_cpu_m": round(actual_cpu_m, 2),
            "requested_memory_mb": round(request_mem_mb, 2),
            "actual_memory_mb": round(actual_mem_mb, 2)
        }

    def calculate_savings(self):
        """
        Aggregate all optimizations executed in database and calculate total savings.
        Returns:
            dict containing savings rates and total cumulative savings.
        """
        optimizations = db.get_optimizations()
        
        total_cpu_m_rate = 0.0
        total_mem_mb_rate = 0.0
        
        # Aggregate savings rates from optimizations
        for opt in optimizations:
            if "Completed" in opt.get("optimization_status", "") or "Simulated" in opt.get("optimization_status", ""):
                saved_str = opt.get("resources_saved", "")
                # Parse e.g., '500m CPU, 256Mi Memory'
                try:
                    parts = saved_str.split(",")
                    if len(parts) == 2:
                        cpu_part = parts[0].replace("CPU", "").strip()
                        mem_part = parts[1].replace("Memory", "").strip()
                        
                        total_cpu_m_rate += convert_cpu_to_millicores(cpu_part)
                        total_mem_mb_rate += convert_memory_to_mb(mem_part)
                except Exception:
                    # Fallback to standard averages if parsing fails
                    total_cpu_m_rate += 250.0
                    total_mem_mb_rate += 128.0

        # Convert millicores to vCPUs, MB to GB
        vcpus_saved = total_cpu_m_rate / 1000.0
        gb_saved = total_mem_mb_rate / 1024.0
        waste_profile = self._calculate_current_waste_profile()
        
        # Hourly savings rates
        cost_saved_per_hour = (vcpus_saved * self.usd_per_vcpu_hour) + (gb_saved * self.usd_per_gb_hour)
        watts_saved = (vcpus_saved * waste_profile["watts_per_vcpu_effective"]) + (gb_saved * self.watts_per_gb)
        
        # Let's assume these optimizations have been active for a running simulation time
        # We can simulate cumulative savings based on database history age or basic scaling
        num_optimizations = len(optimizations)
        
        # Calculate real elapsed time since first optimization
        assumed_hours_active = 1.0  # default fallback
        if optimizations:
            try:
                # get_optimizations() returns records ordered by timestamp DESC
                # so last item is the oldest
                oldest_timestamp_str = optimizations[-1].get("timestamp")
                if oldest_timestamp_str:
                    from datetime import datetime
                    oldest_dt = datetime.fromisoformat(oldest_timestamp_str)
                    elapsed = datetime.utcnow() - oldest_dt
                    assumed_hours_active = min(720.0, elapsed.total_seconds() / 3600.0)
                    assumed_hours_active = max(1.0, assumed_hours_active)
            except Exception:
                assumed_hours_active = 1.0  # safe fallback
                
        # elapsed wall-clock time since first optimization was recorded, capped at 720h (30 days)
        
        cumulative_cost_saved = cost_saved_per_hour * assumed_hours_active
        optimization_kwh_saved = (watts_saved * assumed_hours_active) / 1000.0
        cumulative_kwh_saved = max(optimization_kwh_saved, waste_profile["runtime_weighted_kwh_saved"])
        cumulative_co2_offset = cumulative_kwh_saved * self.co2_g_per_kwh
        
        # Update analytics table in DB
        analytics_record = {
            "total_cpu_saved": total_cpu_m_rate,
            "total_memory_saved": total_mem_mb_rate,
            "energy_saved": round(cumulative_kwh_saved * 1000, 2), # In Watt-hours
            "estimated_cost_reduction": round(cumulative_cost_saved, 4)
        }
        db.save_analytics(analytics_record)

        return {
            "total_cpu_saved_m": total_cpu_m_rate,
            "total_memory_saved_mb": total_mem_mb_rate,
            "hourly_cost_saving_usd": round(cost_saved_per_hour, 4),
            "current_power_saving_watts": max(round(watts_saved, 2), waste_profile["estimated_power_reduction_watts"]),
            "cumulative_cost_saved_usd": round(cumulative_cost_saved, 2),
            "cumulative_kwh_saved": round(cumulative_kwh_saved, 4),
            "estimated_kwh_saved": round(cumulative_kwh_saved, 4),
            "cumulative_co2_offset_g": round(cumulative_co2_offset, 2),
            "energy_before_power_watts": waste_profile["before_power_watts"],
            "energy_after_power_watts": waste_profile["after_power_watts"],
            "energy_power_reduction_watts": waste_profile["estimated_power_reduction_watts"],
            "node_cpu_utilization_percent": waste_profile["node_cpu_utilization_percent"],
            "watts_per_vcpu_effective": waste_profile["watts_per_vcpu_effective"],
            "energy_evaluated_pods": waste_profile["evaluated_pods"],
            "requested_cpu_m": waste_profile["requested_cpu_m"],
            "actual_cpu_m": waste_profile["actual_cpu_m"],
            "requested_memory_mb": waste_profile["requested_memory_mb"],
            "actual_memory_mb": waste_profile["actual_memory_mb"],
            "efficiency_score": max(50, min(100, 100 - (num_optimizations * 3))), # Cluster efficiency score
            "savings_disclaimer": "Energy estimates use pod requests, actual usage, pod uptime, and live node utilization. Figures are approximations unless hardware power telemetry is available."
        }

analytics_engine = AnalyticsEngine()
