from app.config import settings

class DynamicThresholdEngine:
    def __init__(self):
        # Keep a short history of recent average metrics per namespace to compute rolling thresholds
        # Format: {namespace: {"cpu": [val1, val2, ...], "memory": [val1, val2, ...]}}
        self.history = {}
        self.history_limit = 10
        
        # Baselines to avoid thresholds dropping to 0 if pods are fully inactive
        self.min_cpu_threshold = settings.DEFAULT_CPU_THRESHOLD_M
        self.min_mem_threshold = settings.DEFAULT_MEM_THRESHOLD_MB

    def update_and_get_thresholds(self, pods_list, namespace):
        """
        Takes list of currently running pods, updates history for the given namespace,
        and returns (cpu_threshold_millicores, memory_threshold_mb).
        """
        # Filter pods for this namespace
        ns_pods = [p for p in pods_list if p.get('namespace') == namespace]
        
        if not ns_pods:
            return self.min_cpu_threshold, self.min_mem_threshold
            
        # Calculate current namespace average usage
        total_cpu = sum(p.get('cpu_usage', 0.0) for p in ns_pods)
        total_mem = sum(p.get('memory_usage', 0.0) for p in ns_pods)
        
        avg_cpu = total_cpu / len(ns_pods)
        avg_mem = total_mem / len(ns_pods)
        
        # Add to rolling history
        if namespace not in self.history:
            self.history[namespace] = {"cpu": [], "memory": []}
            
        self.history[namespace]["cpu"].append(avg_cpu)
        self.history[namespace]["memory"].append(avg_mem)
        
        # Limit history size
        if len(self.history[namespace]["cpu"]) > self.history_limit:
            self.history[namespace]["cpu"].pop(0)
            self.history[namespace]["memory"].pop(0)
            
        # Compute rolling average usage
        rolling_avg_cpu = sum(self.history[namespace]["cpu"]) / len(self.history[namespace]["cpu"])
        rolling_avg_mem = sum(self.history[namespace]["memory"]) / len(self.history[namespace]["memory"])
        
        # Adaptive logic: threshold = 40% of average CPU, 50% of average Memory
        # But never let it drop below the configured minimum baseline
        adaptive_cpu = max(self.min_cpu_threshold, rolling_avg_cpu * 0.4)
        adaptive_mem = max(self.min_mem_threshold, rolling_avg_mem * 0.5)
        
        return round(adaptive_cpu, 2), round(adaptive_mem, 2)

threshold_engine = DynamicThresholdEngine()
