import json
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.metrics import f1_score, precision_score, recall_score
from sklearn.preprocessing import StandardScaler


BASE_DIR = Path(__file__).resolve().parents[1]
MODEL_PATH = BASE_DIR / "idlepod_model.pkl"
SCALER_PATH = BASE_DIR / "idlepod_scaler.pkl"
METADATA_PATH = BASE_DIR / "model_metadata.json"


def build_training_data(seed=42):
    rng = np.random.default_rng(seed)

    active = np.column_stack([
        rng.uniform(80, 900, 220),      # cpu_usage millicores
        rng.uniform(120, 1800, 220),    # memory_usage MB
        rng.uniform(8, 120, 220),       # request/network activity
        rng.uniform(20, 1800, 220),     # uptime minutes
        rng.integers(0, 3, 220),        # restart count
    ])

    idle = np.column_stack([
        rng.uniform(0, 20, 80),
        rng.uniform(0, 80, 80),
        rng.uniform(0, 1.5, 80),
        rng.uniform(120, 2400, 80),
        rng.integers(0, 2, 80),
    ])

    bursty = np.column_stack([
        rng.uniform(10, 140, 70),
        rng.uniform(60, 500, 70),
        rng.uniform(0.5, 20, 70),
        rng.uniform(30, 900, 70),
        rng.integers(0, 4, 70),
    ])

    features = np.vstack([active, idle, bursty])
    labels = np.concatenate([
        np.zeros(len(active), dtype=int),
        np.ones(len(idle), dtype=int),
        np.zeros(len(bursty), dtype=int),
    ])
    return features, labels


def main():
    training_data, labels = build_training_data()
    scaler = StandardScaler()
    scaled = scaler.fit_transform(training_data)

    # Train the anomaly detector mostly on normal workload behavior, then validate
    # against held-out normal samples plus synthetic idle/anomaly samples.
    normal_training_data = training_data[labels == 0]
    scaler = StandardScaler()
    scaler.fit(normal_training_data)
    validation_data = np.vstack([normal_training_data[:80], training_data[labels == 1]])
    validation_labels = np.concatenate([
        np.zeros(80, dtype=int),
        np.ones(int((labels == 1).sum()), dtype=int),
    ])

    model = IsolationForest(
        n_estimators=200,
        contamination=0.20,
        random_state=42,
    )
    model.fit(scaler.transform(normal_training_data))
    predictions = np.where(model.predict(scaler.transform(validation_data)) == -1, 1, 0)

    joblib.dump(model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)

    metadata = {
        "model_name": "IdlePod Isolation Forest",
        "model_type": "unsupervised",
        "features": [
            "cpu_usage",
            "memory_usage",
            "network_activity",
            "uptime",
            "restart_count"
        ],
        "training_samples": int(training_data.shape[0]),
        "test_f1": round(float(f1_score(validation_labels, predictions, zero_division=0)), 3),
        "test_precision": round(float(precision_score(validation_labels, predictions, zero_division=0)), 3),
        "test_recall": round(float(recall_score(validation_labels, predictions, zero_division=0)), 3),
        "contamination": 0.20,
        "random_state": 42,
        "note": "Synthetic active, idle, and bursty Kubernetes workload telemetry for demo-grade ML validation."
    }
    METADATA_PATH.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    print(f"Saved model: {MODEL_PATH}")
    print(f"Saved scaler: {SCALER_PATH}")
    print(f"Saved metadata: {METADATA_PATH}")


if __name__ == "__main__":
    main()
