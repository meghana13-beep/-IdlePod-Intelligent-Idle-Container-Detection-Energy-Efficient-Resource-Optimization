/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        darkBg: "#0f172a",
        darkCard: "#1e293b",
        glowCyan: "#06b6d4",
        glowGreen: "#10b981",
        glowRed: "#ef4444"
      }
    },
  },
  plugins: [],
}
