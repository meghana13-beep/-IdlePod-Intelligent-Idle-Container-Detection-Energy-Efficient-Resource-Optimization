import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Server, Shield, Leaf, DollarSign, Activity, AlertTriangle, 
  Cpu, Sliders, Cloud, RefreshCw, Layers, CheckCircle2, Play, Bell, UploadCloud,
  Zap, Lock, LogOut, WifiOff
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Legend, PieChart, Pie, Cell
} from 'recharts';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [pods, setPods] = useState([]);
  const [clusterHealth, setClusterHealth] = useState({
    total_pods: 0, active_pods: 0, idle_pods: 0, underutilized_pods: 0, efficiency_score: 100
  });
  const [savings, setSavings] = useState({
    total_cpu_saved_m: 0, total_memory_saved_mb: 0, hourly_cost_saving_usd: 0,
    current_power_saving_watts: 0, cumulative_cost_saved_usd: 0, cumulative_kwh_saved: 0,
    cumulative_co2_offset_g: 0, efficiency_score: 100,
    energy_before_power_watts: 0, energy_after_power_watts: 0,
    energy_power_reduction_watts: 0, node_cpu_utilization_percent: 0,
    watts_per_vcpu_effective: 0, energy_evaluated_pods: 0,
    requested_cpu_m: 0, actual_cpu_m: 0,
    requested_memory_mb: 0, actual_memory_mb: 0
  });
  const [analyticsHistory, setAnalyticsHistory] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [awsLogs, setAwsLogs] = useState([]);
  const [awsCosts, setAwsCosts] = useState({
    status: 'loading',
    total_cost_usd: 0,
    average_daily_cost_usd: 0,
    estimated_savings_usd: 0,
    estimated_savings_vs_real_spend_percent: 0,
    days: [],
    message: ''
  });
  const [optHistory, setOptHistory] = useState([]);
  const [optRecommendations, setOptRecommendations] = useState([]);
  const [mlPredictions, setMlPredictions] = useState([]);
  const [configMode, setConfigMode] = useState('simulation');
  const [backendStatus, setBackendStatus] = useState(null);
  const [backendError, setBackendError] = useState('');
  const [config, setConfig] = useState({ cpu_threshold_m: 50, mem_threshold_mb: 50, idle_checks_required: 2 });
  const [authToken, setAuthToken] = useState(() => localStorage.getItem('idlepod_token') || '');
  const [loginForm, setLoginForm] = useState({ username: 'admin', password: '' });
  const [loginError, setLoginError] = useState('');
  
  useEffect(() => {
    fetch(`${API_BASE}/config`)
      .then(r => r.json())
      .then(data => setConfig(data))
      .catch(() => {}) // keep defaults on failure
  }, []);
  
  // Filters
  const [nsFilter, setNsFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const authHeaders = () => (
    authToken ? { headers: { Authorization: `Bearer ${authToken}` } } : {}
  );

  const requireLogin = () => {
    if (authToken) return true;
    alert('Please log in before running protected operator actions.');
    return false;
  };

  const login = async (e) => {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await axios.post(`${API_BASE}/auth/login`, loginForm);
      localStorage.setItem('idlepod_token', res.data.access_token);
      setAuthToken(res.data.access_token);
      setLoginForm(prev => ({ ...prev, password: '' }));
    } catch (err) {
      setLoginError('Invalid operator credentials');
    }
  };

  const logout = () => {
    localStorage.removeItem('idlepod_token');
    setAuthToken('');
  };

  const fetchData = async () => {
    setIsRefreshing(true);
    try {
      setBackendError('');
      const statusRes = await axios.get(`${API_BASE}/`);
      setBackendStatus(statusRes.data);
      setConfigMode(statusRes.data.mode);

      const requests = await Promise.allSettled([
        axios.get(`${API_BASE}/pods`),
        axios.get(`${API_BASE}/cluster-health`),
        axios.get(`${API_BASE}/analytics/savings`),
        axios.get(`${API_BASE}/analytics/history`),
        axios.get(`${API_BASE}/optimization/recommendations`),
        axios.get(`${API_BASE}/optimization/history`),
        axios.get(`${API_BASE}/alerts`),
        axios.get(`${API_BASE}/aws/logs`),
        axios.get(`${API_BASE}/aws/costs?days=14`),
        axios.get(`${API_BASE}/ml/predictions?limit=20`)
      ]);

      const value = (idx, fallback) => (
        requests[idx].status === 'fulfilled' ? requests[idx].value.data : fallback
      );

      setPods(value(0, []));
      setClusterHealth(value(1, clusterHealth));
      setSavings(value(2, savings));
      setAnalyticsHistory(value(3, []));
      setOptRecommendations(value(4, []));
      setOptHistory(value(5, []));
      setAlerts(value(6, []));
      setAwsLogs(value(7, []));
      setAwsCosts(value(8, awsCosts));
      setMlPredictions(value(9, []));

    } catch (err) {
      console.error("Error communicating with IdlePod Backend:", err);
      setBackendStatus(null);
      setBackendError('Backend is offline or unreachable. Start FastAPI on port 8000, then refresh metrics.');
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const triggerManualOptimization = async (podName, namespace) => {
    if (!requireLogin()) return;
    try {
      await axios.post(`${API_BASE}/optimize?pod_name=${podName}&namespace=${namespace}`, null, authHeaders());
      fetchData();
      alert(`Optimization action dispatched successfully for pod: ${podName}`);
    } catch (err) {
      alert(`Failed to trigger optimization: ${err.message}`);
    }
  };

  const updateOptimizationMode = async (mode) => {
    if (!requireLogin()) return;
    try {
      await axios.post(`${API_BASE}/optimization/mode?mode=${mode}`, null, authHeaders());
      setConfigMode(mode);
      fetchData();
    } catch (err) {
      alert(`Failed to change optimization mode: ${err.message}`);
    }
  };

  const sendManualSnsAlert = async () => {
    if (!requireLogin()) return;
    try {
      await axios.post(`${API_BASE}/aws/send-alert`, null, {
        ...authHeaders(),
        params: {
          subject: "Manual Operator Alert",
          message: "An operator manually tested SNS alert connectivity from the IdlePod dashboard."
        }
      });
      fetchData();
      alert("Simulated/Real SNS Alert Notification sent successfully!");
    } catch (err) {
      alert(`Failed to publish SNS: ${err.message}`);
    }
  };

  const forceS3Upload = async () => {
    if (!requireLogin()) return;
    try {
      await axios.post(`${API_BASE}/aws/upload-logs`, null, authHeaders());
      fetchData();
      alert("Manual telemetry log dump pushed to S3 successfully!");
    } catch (err) {
      alert(`Failed to upload: ${err.message}`);
    }
  };

  const triggerDemoOptimization = () => {
    if (optRecommendations.length === 0) {
      alert('No optimization recommendation is available yet.');
      return;
    }
    const target = optRecommendations[0];
    triggerManualOptimization(target.pod_name, target.namespace);
  };

  const latestAwsAction = (serviceName) => (
    awsLogs.find(log => log.service === serviceName)
  );

  const costExplorerLabel = (() => {
    if (awsCosts.status === 'real') return 'Real spend loaded';
    if (awsCosts.status === 'error' && /DataUnavailableException|not available|not be ingested/i.test(awsCosts.message || '')) {
      return 'Connected, waiting for billing data';
    }
    if (awsCosts.status === 'error') return 'Needs AWS billing setup';
    if (awsCosts.status === 'simulated') return 'Simulated';
    return 'Checking';
  })();

  const costExplorerMessage = (() => {
    if (awsCosts.status === 'error' && /DataUnavailableException|not available|not be ingested/i.test(awsCosts.message || '')) {
      return 'Cost Explorer API is enabled and authenticated. AWS is still preparing billing data, which can take up to 24 hours after first activation.';
    }
    return awsCosts.message || 'No Cost Explorer data available yet. Add ce:GetCostAndUsage permission and refresh.';
  })();

  // Filter pods list
  const filteredPods = pods.filter(p => {
    const matchesNs = nsFilter === 'all' || p.namespace === nsFilter;
    const matchesSearch = p.pod_name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesNs && matchesSearch;
  });

  // Recharts PIE configuration
  const pieData = [
    { name: 'Active', value: clusterHealth.active_pods, color: '#10b981' },
    { name: 'Underutilized', value: clusterHealth.underutilized_pods, color: '#f59e0b' },
    { name: 'Idle', value: clusterHealth.idle_pods, color: '#ef4444' }
  ].filter(d => d.value > 0);

  const awsMode = backendStatus?.aws_simulated === false ? 'Real AWS' : backendStatus ? 'Simulated' : 'Offline';
  const k8sMode = backendStatus?.k8s_connected ? 'Connected' : backendStatus ? 'Simulated' : 'Offline';
  const statusRail = [
    {
      label: 'Backend',
      value: backendStatus ? 'Online' : 'Offline',
      tone: backendStatus ? 'ok' : 'bad',
      icon: Activity
    },
    {
      label: 'Kubernetes',
      value: k8sMode,
      tone: backendStatus?.k8s_connected ? 'ok' : backendStatus ? 'warn' : 'bad',
      icon: Server
    },
    {
      label: 'AWS Mode',
      value: awsMode,
      tone: backendStatus?.aws_simulated === false ? 'ok' : backendStatus ? 'warn' : 'bad',
      icon: Cloud
    },
    {
      label: 'Optimization',
      value: configMode,
      tone: configMode === 'automatic' ? 'warn' : 'ok',
      icon: Shield
    }
  ];

  const toneClasses = {
    ok: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300',
    warn: 'border-amber-500/30 bg-amber-500/10 text-amber-300',
    bad: 'border-red-500/30 bg-red-500/10 text-red-300'
  };

  return (
    <div className="min-h-screen bg-darkBg text-slate-100 flex flex-col app-shell">
      {/* HEADER BANNER */}
      <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur sticky top-0 z-50 px-4 md:px-6 py-4 flex flex-col xl:flex-row justify-between gap-4 xl:items-center shadow-[0_12px_40px_rgba(0,0,0,0.25)]">
        <div className="flex items-center gap-3 min-w-0">
          <div className="bg-glowCyan/15 p-2 rounded-lg border border-glowCyan/30 shrink-0">
            <Layers className="h-6 w-6 text-glowCyan pulse-glow" />
          </div>
          <div className="min-w-0">
            <h1 className="text-lg md:text-xl font-bold tracking-tight text-slate-50 flex items-center flex-wrap gap-2">
              IdlePod <span className="ml-2 text-xs font-semibold px-2 py-0.5 rounded bg-cyan-950 text-glowCyan border border-cyan-800">v2.0 Enterprise</span>
            </h1>
            <p className="text-xs text-slate-400">Intelligent Green-Cloud Kubernetes Optimization</p>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className={`status-chip ${backendStatus ? 'status-chip-ok' : 'status-chip-bad'}`}>
            <span className="status-dot"></span>
            <span>Backend {backendStatus ? 'Online' : 'Offline'}</span>
          </div>
          <div className={`status-chip ${backendStatus?.k8s_connected ? 'status-chip-ok' : 'status-chip-warn'}`}>
            <Server className="h-3.5 w-3.5" />
            <span>Kubernetes {k8sMode}</span>
          </div>
          <div className={`status-chip ${backendStatus?.aws_simulated === false ? 'status-chip-ok' : 'status-chip-warn'}`}>
            <Cloud className="h-3.5 w-3.5" />
            <span>AWS Mode {awsMode}</span>
          </div>

          {authToken ? (
            <button
              onClick={logout}
              className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-300 bg-emerald-950/30 border border-emerald-900/50 px-3 py-1.5 rounded-lg hover:bg-emerald-900/40 transition"
            >
              <LogOut className="h-3.5 w-3.5" />
              Operator Authenticated
            </button>
          ) : (
            <form onSubmit={login} className="flex items-center gap-2 flex-wrap">
              <input
                type="text"
                value={loginForm.username}
                onChange={(e) => setLoginForm(prev => ({ ...prev, username: e.target.value }))}
                className="w-24 bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-glowCyan"
                placeholder="User"
              />
              <input
                type="password"
                value={loginForm.password}
                onChange={(e) => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                className="w-32 bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-glowCyan"
                placeholder="Password"
              />
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-glowCyan bg-glowCyan/10 border border-glowCyan/40 px-3 py-1.5 rounded-lg hover:bg-glowCyan hover:text-darkBg transition"
              >
                <Lock className="h-3.5 w-3.5" />
                Login
              </button>
              {loginError && <span className="text-2xs text-red-400">{loginError}</span>}
            </form>
          )}

          <button 
            onClick={fetchData} 
            className="icon-button"
            title="Refresh metrics"
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <div className="flex flex-1 flex-col lg:flex-row">
        {/* SIDEBAR NAVIGATION */}
        <aside className="lg:w-64 border-r border-slate-800/70 bg-slate-950/40 p-4 lg:p-6 flex lg:flex-col justify-between gap-4 overflow-x-auto lg:overflow-visible">
          <div className="space-y-4 min-w-max lg:min-w-0">
            <div className="hidden lg:block text-xs font-bold uppercase tracking-wider text-slate-500">Navigation</div>
            <nav className="flex lg:block gap-2 lg:space-y-1.5">
              {[
                { id: 'dashboard', label: 'Home Dashboard', icon: Activity },
                { id: 'monitor', label: 'Pod Monitoring', icon: Server },
                { id: 'optimize', label: 'Optimization Center', icon: Shield },
                { id: 'analytics', label: 'Energy Analytics', icon: Leaf },
                { id: 'aws', label: 'AWS Integrations', icon: Cloud },
                { id: 'config', label: 'Configuration', icon: Sliders }
              ].map(tab => {
                const Icon = tab.icon;
                const isSelected = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 rounded-lg text-sm font-medium transition whitespace-nowrap ${
                      isSelected 
                        ? 'bg-glowCyan/10 border border-glowCyan/30 text-glowCyan' 
                        : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* GREEN COMPUTING WIDGET */}
          <div className="hidden lg:block glass-panel p-4 rounded-xl space-y-3 border-emerald-950 glow-shadow-green bg-emerald-950/5">
            <div className="flex items-center space-x-2 text-glowGreen">
              <Leaf className="h-4 w-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Carbon Offset</span>
            </div>
            <div>
              <div className="text-2xl font-bold text-slate-100">{savings.cumulative_co2_offset_g} g</div>
              <p className="text-2xs text-slate-400 leading-tight">Total Carbon emissions saved from automated pod optimizations.</p>
            </div>
            <div className="text-2xs text-glowGreen font-semibold">
              Power saved: {savings.current_power_saving_watts} W
            </div>
          </div>
        </aside>

        {/* WORKSPACE CONTENT AREA */}
        <main className="flex-1 p-4 md:p-6 xl:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
          {backendError && (
            <div className="mb-6 glass-panel border-red-900/50 bg-red-950/20 p-5 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <WifiOff className="h-5 w-5 text-red-300 mt-0.5" />
                <div>
                  <div className="text-sm font-bold text-red-200">Live telemetry is disconnected</div>
                  <div className="text-xs text-red-100/70 mt-1">{backendError}</div>
                </div>
              </div>
              <button onClick={fetchData} className="demo-button demo-button-primary">
                <RefreshCw className="h-4 w-4" />
                Refresh Metrics
              </button>
            </div>
          )}

          <section className="mb-6 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
            {statusRail.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.label} className={`status-card ${toneClasses[item.tone]}`}>
                  <div className="flex items-center gap-2 text-xs uppercase tracking-wider opacity-80">
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </div>
                  <div className="mt-2 text-lg font-bold">{item.value}</div>
                </div>
              );
            })}
          </section>

          <section className="mb-8 glass-panel p-4 rounded-xl flex flex-col xl:flex-row xl:items-center justify-between gap-4">
            <div>
              <div className="text-sm font-bold text-slate-100">Demo Control Bar</div>
              <div className="text-xs text-slate-400 mt-1">Use these actions during evaluation after logging in as an operator.</div>
            </div>
            <div className="grid grid-cols-2 md:flex gap-2">
              <button onClick={sendManualSnsAlert} className="demo-button">
                <Bell className="h-4 w-4" />
                Send SNS Test
              </button>
              <button onClick={forceS3Upload} className="demo-button">
                <UploadCloud className="h-4 w-4" />
                Force S3 Upload
              </button>
              <button onClick={triggerDemoOptimization} className="demo-button">
                <Zap className="h-4 w-4" />
                Trigger Optimization
              </button>
              <button onClick={fetchData} className="demo-button demo-button-primary">
                <RefreshCw className="h-4 w-4" />
                Refresh Metrics
              </button>
            </div>
          </section>

          <section className="mb-8 glass-panel p-5 rounded-xl">
            <div className="flex items-center justify-between gap-4 flex-wrap mb-4">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Demo Proof Panel</h3>
                <p className="text-xs text-slate-500 mt-1">Live evidence for deployment, AWS, database-backed telemetry, and optimization workflow.</p>
              </div>
              <button onClick={fetchData} className="demo-button demo-button-primary">
                <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
                Refresh Proof
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
              {[
                { label: 'Backend API', value: backendStatus ? 'Online' : 'Offline', detail: backendStatus?.timestamp?.replace('T', ' ').substring(0, 19) || 'No response', tone: backendStatus ? 'text-emerald-300' : 'text-red-300' },
                { label: 'AWS Mode', value: awsMode, detail: latestAwsAction('CloudWatch') ? `CloudWatch ${latestAwsAction('CloudWatch').status}` : 'Awaiting metric push', tone: backendStatus?.aws_simulated === false ? 'text-emerald-300' : 'text-amber-300' },
                { label: 'MongoDB Telemetry', value: `${pods.length} pods`, detail: `${optHistory.length} optimizations, ${alerts.length} alerts`, tone: pods.length > 0 ? 'text-cyan-300' : 'text-slate-300' },
                { label: 'Kubernetes Mode', value: k8sMode, detail: backendStatus?.k8s_connected ? 'Live cluster metrics' : 'Simulator fallback active', tone: backendStatus?.k8s_connected ? 'text-emerald-300' : 'text-amber-300' },
                { label: 'SNS Alert', value: latestAwsAction('SNS')?.status || 'Ready', detail: latestAwsAction('SNS')?.timestamp?.replace('T', ' ').substring(0, 19) || 'Use Send SNS Test', tone: latestAwsAction('SNS') ? 'text-emerald-300' : 'text-slate-300' },
                { label: 'S3 Report', value: latestAwsAction('S3')?.status || 'Ready', detail: latestAwsAction('S3')?.payload?.Key || 'Use Force S3 Upload', tone: latestAwsAction('S3') ? 'text-emerald-300' : 'text-slate-300' },
                { label: 'Cost Explorer', value: costExplorerLabel, detail: awsCosts.status === 'real' ? `$${Number(awsCosts.total_cost_usd || 0).toFixed(2)} last 14 days` : 'Billing data may be delayed', tone: awsCosts.status === 'real' ? 'text-emerald-300' : 'text-amber-300' },
                { label: 'ML Validation', value: `${mlPredictions.length} predictions`, detail: mlPredictions[0]?.ml_label || 'Waiting for next cycle', tone: mlPredictions.length ? 'text-purple-300' : 'text-slate-300' }
              ].map((item) => (
                <div key={item.label} className="rounded-lg border border-slate-800 bg-slate-950/30 p-4">
                  <p className="text-2xs uppercase tracking-widest text-slate-500">{item.label}</p>
                  <p className={`text-lg font-bold mt-1 ${item.tone}`}>{item.value}</p>
                  <p className="text-2xs text-slate-500 mt-1 truncate">{item.detail}</p>
                </div>
              ))}
            </div>
          </section>

          {/* TAB 1: OVERVIEW DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8">
              {/* TOP METRIC CARDS */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
                {[
                  { title: 'Total Pods Monitored', value: clusterHealth.total_pods, sub: 'Across 3 Namespaces', icon: Server, color: 'text-cyan-400' },
                  { title: 'Idle Pods Flagged', value: clusterHealth.idle_pods, sub: 'Needs scale down', icon: AlertTriangle, color: 'text-red-400' },
                  { title: 'Cluster Efficiency', value: `${clusterHealth.efficiency_score}%`, sub: 'Resource utilization index', icon: Activity, color: 'text-emerald-400' },
                  { title: 'Total Savings Rate', value: `$${savings.hourly_cost_saving_usd}/hr`, sub: `Cumulative: $${savings.cumulative_cost_saved_usd}`, icon: DollarSign, color: 'text-yellow-400' }
                ].map((card, idx) => {
                  const Icon = card.icon;
                  return (
                    <div key={idx} className="glass-panel p-6 rounded-xl relative overflow-hidden flex flex-col justify-between">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{card.title}</p>
                          <h3 className="text-3xl font-extrabold text-slate-100 mt-2">{card.value}</h3>
                        </div>
                        <div className={`p-2 rounded-lg bg-slate-800/80 border border-slate-700/50 ${card.color}`}>
                          <Icon className="h-5 w-5" />
                        </div>
                      </div>
                      <p className="text-2xs text-slate-500 mt-3">{card.sub}</p>
                    </div>
                  );
                })}
              </div>

              {/* CORE DASHBOARD GRID */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Cluster Distribution */}
                <div className="glass-panel p-6 rounded-xl col-span-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4">Pod Distribution</h3>
                    <div className="h-44 flex justify-center items-center relative">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={70}
                            paddingAngle={3}
                            dataKey="value"
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="absolute text-center">
                        <span className="text-3xl font-bold text-slate-200">{clusterHealth.total_pods}</span>
                        <p className="text-2xs text-slate-500 uppercase tracking-widest">Pods</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2 mt-4 text-xs">
                    {pieData.map((d, i) => (
                      <div key={i} className="flex justify-between items-center px-3 py-1.5 rounded bg-slate-800/30 border border-slate-800">
                        <div className="flex items-center space-x-2">
                          <span className="h-2 w-2 rounded-full" style={{ backgroundColor: d.color }}></span>
                          <span className="text-slate-300">{d.name}</span>
                        </div>
                        <span className="font-semibold text-slate-100">{d.value}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Savings Graph */}
                <div className="glass-panel p-6 rounded-xl lg:col-span-2">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4">Cumulative Cost Savings Trend</h3>
                  <div className="h-60">
                    {analyticsHistory.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-500">
                        Gathering savings metrics. Check back in a few seconds...
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={analyticsHistory}>
                          <defs>
                            <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#eab308" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                          <XAxis dataKey="timestamp" stroke="#64748b" fontSize={10} tickFormatter={(tick) => tick.split('T')[1]?.substring(0,5) || tick} />
                          <YAxis stroke="#64748b" fontSize={10} unit="$" />
                          <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                          <Area type="monotone" dataKey="estimated_cost_reduction" stroke="#eab308" fillOpacity={1} fill="url(#colorCost)" name="Savings (USD)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>
              </div>

              {/* RECENT ALERTS */}
              <div className="glass-panel p-6 rounded-xl">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Cluster Security & Optimization Alerts</h3>
                  <span className="text-xs text-slate-500 font-medium">Recent 5 Alerts</span>
                </div>
                <div className="space-y-3">
                  {alerts.slice(0, 5).map((a, i) => (
                    <div key={i} className={`flex items-start space-x-3 px-4 py-3 rounded-lg border text-sm ${
                      a.severity === 'Warning' 
                        ? 'bg-amber-950/15 border-amber-900/40 text-amber-300' 
                        : a.severity === 'Critical' 
                          ? 'bg-red-950/15 border-red-900/40 text-red-300'
                          : 'bg-slate-800/40 border-slate-800 text-slate-300'
                    }`}>
                      <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                      <div className="flex-1 flex justify-between">
                        <span>{a.message}</span>
                        <span className="text-2xs text-slate-500 ml-4 font-mono">{a.timestamp.substring(11, 19)}</span>
                      </div>
                    </div>
                  ))}
                  {alerts.length === 0 && (
                    <div className="text-center py-6 text-xs text-slate-500">
                      No active resource warnings in the cluster. Green Cloud operating optimally.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: POD MONITORING */}
          {activeTab === 'monitor' && (
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h2 className="text-xl font-bold">Pod Metrics Telemetry</h2>
                  <p className="text-xs text-slate-400">Real-time status analysis against dynamic adaptive baselines</p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  {/* Search */}
                  <input
                    type="text"
                    placeholder="Search Pod name..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-xs w-44 focus:outline-none focus:border-glowCyan text-slate-200"
                  />

                  {/* Namespace Filter */}
                  <select 
                    value={nsFilter}
                    onChange={(e) => setNsFilter(e.target.value)}
                    className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-xs focus:outline-none focus:border-glowCyan text-slate-200"
                  >
                    <option value="all">All Namespaces</option>
                    <option value="production">production</option>
                    <option value="development">development</option>
                    <option value="testing">testing</option>
                  </select>
                </div>
              </div>

              {/* TABLE SNAPSHOT */}
              <div className="glass-panel rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-900/60 border-b border-slate-800 text-slate-400 uppercase tracking-wider">
                        <th className="px-6 py-4 font-semibold">Pod Name</th>
                        <th className="px-6 py-4 font-semibold">Namespace</th>
                        <th className="px-6 py-4 font-semibold text-center">CPU Req</th>
                        <th className="px-6 py-4 font-semibold text-center">CPU Usage</th>
                        <th className="px-6 py-4 font-semibold text-center">Memory Req</th>
                        <th className="px-6 py-4 font-semibold text-center">Memory Usage</th>
                        <th className="px-6 py-4 font-semibold text-center">Net Load</th>
                        <th className="px-6 py-4 font-semibold text-center">Idle Score</th>
                        <th className="px-6 py-4 font-semibold text-center">ML Prediction</th>
                        <th className="px-6 py-4 font-semibold text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {filteredPods.map((pod, idx) => {
                        let statusColor = 'bg-slate-800 text-slate-400 border-slate-700';
                        if (pod.status === 'Active') statusColor = 'bg-emerald-950/20 text-emerald-400 border-emerald-900/40';
                        if (pod.status === 'Underutilized') statusColor = 'bg-amber-950/20 text-amber-400 border-amber-900/40';
                        if (pod.status === 'Idle') statusColor = 'bg-red-950/20 text-red-400 border-red-900/40';
                        const mlLabel = pod.ml_label || (pod.ml_prediction === 'Anomaly' ? 'Suspicious Idle' : 'Active Pattern');
                        
                        return (
                          <tr key={idx} className="hover:bg-slate-800/20 transition">
                            <td className="px-6 py-3 font-semibold text-slate-200 font-mono">{pod.pod_name}</td>
                            <td className="px-6 py-3 text-slate-400">{pod.namespace}</td>
                            <td className="px-6 py-3 text-center text-slate-400 font-mono">{pod.cpu_requested}</td>
                            <td className="px-6 py-3 text-center text-slate-200 font-mono">{pod.cpu_usage}m</td>
                            <td className="px-6 py-3 text-center text-slate-400 font-mono">{pod.memory_requested}</td>
                            <td className="px-6 py-3 text-center text-slate-200 font-mono">{pod.memory_usage} MB</td>
                            <td className="px-6 py-3 text-center text-slate-400 font-mono">{pod.network_activity} req/s</td>
                            <td className="px-6 py-3 text-center">
                              <span className={`font-bold ${pod.idle_score > 70 ? 'text-red-400' : pod.idle_score > 40 ? 'text-amber-400' : 'text-emerald-400'}`}>
                                {pod.idle_score}%
                              </span>
                            </td>
                            <td className="px-6 py-3 text-center">
                              <span className={`px-2 py-0.5 rounded-full border text-2xs font-medium font-mono ${
                                pod.ml_prediction === 'Anomaly' 
                                  ? 'bg-purple-950/20 text-purple-400 border-purple-900/50 glow-shadow-purple' 
                                  : 'bg-slate-800/30 text-slate-400 border-slate-700/50'
                              }`}>
                                {mlLabel}
                              </span>
                            </td>
                            <td className="px-6 py-3 text-center">
                              <span className={`px-2.5 py-1 rounded-full border text-2xs font-semibold uppercase ${statusColor}`}>
                                {pod.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                      {filteredPods.length === 0 && (
                        <tr>
                          <td colSpan="10" className="text-center py-8 text-slate-500">
                            No active matching pods found. Make sure backend telemetry loop is running.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: OPTIMIZATION CENTER */}
          {activeTab === 'optimize' && (
            <div className="space-y-8">
              <div>
                <h2 className="text-xl font-bold">Optimization Control Center</h2>
                <p className="text-xs text-slate-400">View and approve intelligent container consolidation recommendations</p>
              </div>

              {/* CURRENT RECOMMENDATIONS */}
              <div className="glass-panel p-6 rounded-xl space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center">
                  <Shield className="h-4 w-4 text-glowCyan mr-2" />
                  Live Resource Consolidation Recommendations
                </h3>
                <div className="space-y-3">
                  {optRecommendations.map((rec, i) => (
                    <div key={i} className="flex flex-col md:flex-row justify-between items-start md:items-center px-6 py-4 rounded-xl border border-slate-800 bg-slate-900/50 hover:border-slate-700 transition gap-4">
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest font-mono">[{rec.namespace}]</span>
                          <span className="font-bold text-slate-200 text-sm">{rec.pod_name}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">
                          Recommendation: <span className="text-cyan-400 font-semibold">{rec.recommendation}</span>
                        </p>
                        <div className="flex items-center space-x-3 mt-2 text-2xs">
                          <span className="text-red-400 font-bold">Idle Confidence: {rec.idle_score}%</span>
                          <span className="text-slate-500">|</span>
                          <span className={`px-1.5 py-0.5 rounded font-mono ${
                            rec.priority === 'High' ? 'bg-red-950/40 text-red-400 border border-red-900/50' : 'bg-amber-950/40 text-amber-400 border border-amber-900/50'
                          }`}>Priority: {rec.priority}</span>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2 w-full md:w-auto">
                        <button 
                          onClick={() => triggerManualOptimization(rec.pod_name, rec.namespace)}
                          className="flex-1 md:flex-none flex items-center justify-center space-x-1.5 bg-glowCyan/10 hover:bg-glowCyan hover:text-darkBg border border-glowCyan/40 text-glowCyan px-4 py-2 rounded-lg text-xs font-bold transition duration-300"
                        >
                          <Play className="h-3.5 w-3.5" />
                          <span>Approve & Scale Down</span>
                        </button>
                      </div>
                    </div>
                  ))}
                  {optRecommendations.length === 0 && (
                    <div className="text-center py-8 text-xs text-slate-500">
                      No scaling recommendations available. All workloads match utilization baselines.
                    </div>
                  )}
                </div>
              </div>

              {/* EXECUTION HISTORY LOG */}
              <div className="glass-panel p-6 rounded-xl">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center">
                  <CheckCircle2 className="h-4 w-4 text-glowGreen mr-2" />
                  Optimization Execution Audit Log
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="text-slate-500 border-b border-slate-800 uppercase tracking-widest pb-3">
                        <th className="pb-3 font-semibold">Execution Timestamp</th>
                        <th className="pb-3 font-semibold">Target Pod</th>
                        <th className="pb-3 font-semibold">Namespace</th>
                        <th className="pb-3 font-semibold">Optimization Action</th>
                        <th className="pb-3 font-semibold text-center">Resources Saved</th>
                        <th className="pb-3 font-semibold text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850">
                      {optHistory.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-800/10">
                          <td className="py-3 text-slate-500 font-mono">{item.timestamp.replace('T', ' ').substring(0, 19)}</td>
                          <td className="py-3 font-bold text-slate-300 font-mono">{item.pod_name}</td>
                          <td className="py-3 text-slate-400">{item.namespace}</td>
                          <td className="py-3 text-cyan-400 font-medium">{item.action_taken}</td>
                          <td className="py-3 text-center text-emerald-400 font-semibold font-mono">{item.resources_saved}</td>
                          <td className="py-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-2xs font-bold uppercase ${
                              item.optimization_status === 'Completed' ? 'bg-emerald-950/20 text-emerald-400 border border-emerald-900/30' : 'bg-slate-800 text-slate-400 border border-slate-700/30'
                            }`}>
                              {item.optimization_status}
                            </span>
                          </td>
                        </tr>
                      ))}
                      {optHistory.length === 0 && (
                        <tr>
                          <td colSpan="6" className="text-center py-6 text-slate-500">
                            No optimization tasks executed yet.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ENERGY ANALYTICS */}
          {activeTab === 'analytics' && (
            <div className="space-y-8">
              <div>
                <h2 className="text-xl font-bold">Green Cloud Energy Analytics</h2>
                <p className="text-xs text-slate-400">Assess estimated electrical offsets and server footprint shrinkage</p>
              </div>

              {/* CARDS */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
                <div className="glass-panel p-6 rounded-xl flex items-center space-x-4 border-emerald-950 glow-shadow-green">
                  <div className="p-3 rounded-lg bg-emerald-950 text-glowGreen">
                    <Leaf className="h-6 w-6" />
                  </div>
                  <div>
                    <span className="text-2xs font-semibold text-slate-400 uppercase tracking-wider">Total Power Saved</span>
                    <h4 className="text-2xl font-bold text-slate-100 mt-1">{savings.cumulative_kwh_saved.toFixed(4)} kWh</h4>
                    <p className="text-2xs text-slate-500 mt-0.5">Equivalent to {savings.cumulative_co2_offset_g.toFixed(1)}g CO2</p>
                  </div>
                </div>

                <div className="glass-panel p-6 rounded-xl flex items-center space-x-4 border-yellow-950 glow-shadow-yellow">
                  <div className="p-3 rounded-lg bg-yellow-950 text-yellow-400">
                    <DollarSign className="h-6 w-6" />
                  </div>
                  <div>
                    <span className="text-2xs font-semibold text-slate-400 uppercase tracking-wider">Estimated Cost Reduction</span>
                    <h4 className="text-2xl font-bold text-slate-100 mt-1">${savings.cumulative_cost_saved_usd.toFixed(2)} USD</h4>
                    <p className="text-2xs text-slate-500 mt-0.5">Savings rate: ${savings.hourly_cost_saving_usd.toFixed(4)}/hr</p>
                  </div>
                </div>

                <div className="glass-panel p-6 rounded-xl flex items-center space-x-4 border-amber-950 glow-shadow-yellow">
                  <div className="p-3 rounded-lg bg-amber-950 text-yellow-400">
                    <Cloud className="h-6 w-6" />
                  </div>
                  <div>
                    <span className="text-2xs font-semibold text-slate-400 uppercase tracking-wider">Real AWS Spend</span>
                    <h4 className="text-2xl font-bold text-slate-100 mt-1">${Number(awsCosts.total_cost_usd || 0).toFixed(2)} USD</h4>
                    <p className="text-2xs text-slate-500 mt-0.5">
                      {awsCosts.status === 'real'
                        ? `${Number(awsCosts.estimated_savings_vs_real_spend_percent || 0).toFixed(2)}% estimated offset`
                        : awsCosts.status === 'error'
                          ? costExplorerLabel
                          : 'Waiting for billing data'}
                    </p>
                  </div>
                </div>

                <div className="glass-panel p-6 rounded-xl flex items-center space-x-4 border-cyan-950 glow-shadow-cyan">
                  <div className="p-3 rounded-lg bg-cyan-950 text-glowCyan">
                    <Cpu className="h-6 w-6" />
                  </div>
                  <div>
                    <span className="text-2xs font-semibold text-slate-400 uppercase tracking-wider">Capacity Restored</span>
                    <h4 className="text-2xl font-bold text-slate-100 mt-1">{(savings.total_cpu_saved_m / 1000).toFixed(2)} vCPU</h4>
                    <p className="text-2xs text-slate-500 mt-0.5">RAM Saved: {(savings.total_memory_saved_mb / 1024).toFixed(2)} GB</p>
                  </div>
                </div>
              </div>

              {/* ENERGY GRAPHS */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Before/after energy model */}
                <div className="glass-panel p-6 rounded-xl lg:col-span-2">
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div>
                      <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">Before / After Energy Model</h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Uses pod request values, live usage, pod runtime, and node CPU utilization to estimate avoidable power draw.
                      </p>
                    </div>
                    <span className="px-3 py-1 rounded-lg border border-emerald-900/50 bg-emerald-950/20 text-emerald-300 text-xs font-semibold">
                      Estimated kWh saved: {Number(savings.estimated_kwh_saved || savings.cumulative_kwh_saved || 0).toFixed(4)}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-5">
                    <div className="rounded-lg border border-slate-800 bg-slate-950/30 p-4">
                      <p className="text-2xs uppercase tracking-widest text-slate-500">Before allocation</p>
                      <p className="text-2xl font-bold text-slate-100 mt-1">{Number(savings.energy_before_power_watts || 0).toFixed(2)} W</p>
                      <p className="text-2xs text-slate-500 mt-1">Requested CPU/memory power</p>
                    </div>
                    <div className="rounded-lg border border-slate-800 bg-slate-950/30 p-4">
                      <p className="text-2xs uppercase tracking-widest text-slate-500">After usage</p>
                      <p className="text-2xl font-bold text-slate-100 mt-1">{Number(savings.energy_after_power_watts || 0).toFixed(2)} W</p>
                      <p className="text-2xs text-slate-500 mt-1">Actual observed workload draw</p>
                    </div>
                    <div className="rounded-lg border border-emerald-900/40 bg-emerald-950/10 p-4">
                      <p className="text-2xs uppercase tracking-widest text-emerald-400">Power reduction</p>
                      <p className="text-2xl font-bold text-emerald-300 mt-1">{Number(savings.energy_power_reduction_watts || 0).toFixed(2)} W</p>
                      <p className="text-2xs text-slate-500 mt-1">Runtime-weighted savings basis</p>
                    </div>
                    <div className="rounded-lg border border-cyan-900/40 bg-cyan-950/10 p-4">
                      <p className="text-2xs uppercase tracking-widest text-cyan-400">Node factor</p>
                      <p className="text-2xl font-bold text-cyan-300 mt-1">{Number(savings.node_cpu_utilization_percent || 0).toFixed(1)}%</p>
                      <p className="text-2xs text-slate-500 mt-1">{Number(savings.watts_per_vcpu_effective || 0).toFixed(2)} W per vCPU</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 text-xs text-slate-400">
                    <div>Evaluated idle/underused pods: <span className="text-slate-100 font-semibold">{savings.energy_evaluated_pods || 0}</span></div>
                    <div>CPU request vs use: <span className="text-slate-100 font-semibold">{Number(savings.requested_cpu_m || 0).toFixed(0)}m / {Number(savings.actual_cpu_m || 0).toFixed(0)}m</span></div>
                    <div>Memory request vs use: <span className="text-slate-100 font-semibold">{Number(savings.requested_memory_mb || 0).toFixed(0)}Mi / {Number(savings.actual_memory_mb || 0).toFixed(0)}Mi</span></div>
                  </div>
                </div>

                {/* Cost savings curve */}
                <div className="glass-panel p-6 rounded-xl">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4">Cost Optimization Curve</h3>
                  <div className="h-60">
                    {analyticsHistory.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-500">
                        Gathering history...
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={analyticsHistory}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                          <XAxis dataKey="timestamp" stroke="#64748b" fontSize={10} tickFormatter={(tick) => tick.split('T')[1]?.substring(0,5) || tick} />
                          <YAxis stroke="#64748b" fontSize={10} unit="$" />
                          <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                          <Area type="monotone" dataKey="estimated_cost_reduction" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.05} name="Savings ($)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>

                {/* Real AWS spend curve */}
                <div className="glass-panel p-6 rounded-xl">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4">Real AWS Cost Explorer Spend</h3>
                  <div className="h-60">
                    {awsCosts.days.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-500 text-center px-6">
                        {costExplorerMessage}
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={awsCosts.days}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                          <XAxis dataKey="date" stroke="#64748b" fontSize={10} />
                          <YAxis stroke="#64748b" fontSize={10} unit="$" />
                          <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                          <Area type="monotone" dataKey="cost_usd" stroke="#38bdf8" fill="#38bdf8" fillOpacity={0.06} name="AWS Spend ($)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                  <p className="text-2xs text-slate-500 mt-3">
                    Daily unblended AWS cost from Cost Explorer. Billing data can be delayed.
                  </p>
                </div>

                {/* Energy curve */}
                <div className="glass-panel p-6 rounded-xl">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4">Electrical Power Savings Trend</h3>
                  <div className="h-60">
                    {analyticsHistory.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-slate-500">
                        Gathering history...
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={analyticsHistory}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                          <XAxis dataKey="timestamp" stroke="#64748b" fontSize={10} tickFormatter={(tick) => tick.split('T')[1]?.substring(0,5) || tick} />
                          <YAxis stroke="#64748b" fontSize={10} unit="Wh" />
                          <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                          <Area type="monotone" dataKey="energy_saved" stroke="#10b981" fill="#10b981" fillOpacity={0.05} name="Energy Saved (Wh)" />
                        </AreaChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>
              </div>

              <div className="glass-panel p-6 rounded-xl">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4">ML Validation History</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="text-slate-500 border-b border-slate-800 uppercase tracking-widest">
                        <th className="pb-3 font-semibold">Timestamp</th>
                        <th className="pb-3 font-semibold">Pod</th>
                        <th className="pb-3 font-semibold">Namespace</th>
                        <th className="pb-3 font-semibold text-center">ML Prediction</th>
                        <th className="pb-3 font-semibold text-center">Idle Score</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850">
                      {mlPredictions.slice(0, 10).map((item, idx) => (
                        <tr key={idx}>
                          <td className="py-3 text-slate-500 font-mono">{item.timestamp?.replace('T', ' ').substring(0, 19)}</td>
                          <td className="py-3 text-slate-300 font-mono">{item.pod_name}</td>
                          <td className="py-3 text-slate-400">{item.namespace}</td>
                          <td className="py-3 text-center">
                            <span className={`px-2 py-0.5 rounded-full border text-2xs font-semibold ${
                              item.prediction === 'Anomaly'
                                ? 'bg-purple-950/20 text-purple-400 border-purple-900/50'
                                : 'bg-slate-800/30 text-slate-400 border-slate-700/50'
                            }`}>
                              {item.ml_label || item.prediction}
                            </span>
                          </td>
                          <td className="py-3 text-center text-red-400 font-mono">{item.idle_score}%</td>
                        </tr>
                      ))}
                      {mlPredictions.length === 0 && (
                        <tr>
                          <td colSpan="5" className="text-center py-6 text-slate-500">
                            ML validation history will appear after the next monitoring cycle.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: AWS INTEGRATIONS */}
          {activeTab === 'aws' && (
            <div className="space-y-8">
              <div className="flex justify-between items-center flex-wrap gap-4">
                <div>
                  <h2 className="text-xl font-bold">AWS Cloud Integrations</h2>
                  <p className="text-xs text-slate-400">Audit AWS SDK API log activities for CloudWatch, SNS, S3, and Lambda</p>
                </div>

                <div className="flex items-center space-x-2">
                  <button 
                    onClick={sendManualSnsAlert}
                    className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition"
                  >
                    Send Test SNS alert
                  </button>
                  <button 
                    onClick={forceS3Upload}
                    className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs px-3 py-1.5 rounded-lg transition"
                  >
                    Force S3 Upload
                  </button>
                </div>
              </div>

              {/* AWS API ACTIVITY LIST */}
              <div className="glass-panel p-6 rounded-xl">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 flex items-center">
                  <Cloud className="h-4 w-4 text-glowCyan mr-2 animate-bounce" />
                  AWS Cloud Service Log Activity Audit
                </h3>
                <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                  {awsLogs.map((log, idx) => {
                    let badgeColor = 'bg-slate-800 text-slate-400';
                    if (log.service === 'CloudWatch') badgeColor = 'bg-cyan-950/30 text-cyan-400 border border-cyan-900/40';
                    if (log.service === 'SNS') badgeColor = 'bg-amber-950/30 text-amber-400 border border-amber-900/40';
                    if (log.service === 'S3') badgeColor = 'bg-emerald-950/30 text-emerald-400 border border-emerald-900/40';
                    if (log.service === 'Lambda') badgeColor = 'bg-purple-950/30 text-purple-400 border border-purple-900/40';

                    return (
                      <div key={idx} className="p-4 rounded-xl border border-slate-850 bg-slate-900/20 flex flex-col gap-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-0.5 rounded text-2xs font-bold uppercase font-mono ${badgeColor}`}>
                              AWS {log.service}
                            </span>
                            <span className="text-xs text-slate-500 font-mono">{log.action}</span>
                          </div>
                          <span className="text-2xs text-slate-600 font-mono">{log.timestamp.replace('T', ' ').substring(0, 19)}</span>
                        </div>
                        <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-900 font-mono text-2xs text-slate-400 overflow-x-auto max-h-32">
                          <pre>{JSON.stringify(log.payload, null, 2)}</pre>
                        </div>
                      </div>
                    );
                  })}
                  {awsLogs.length === 0 && (
                    <div className="text-center py-10 text-xs text-slate-500">
                      No AWS actions logged yet. Start monitoring to push CloudWatch and S3 records.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: CONFIGURATION */}
          {activeTab === 'config' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold">Heuristics & Engine Settings</h2>
                <p className="text-xs text-slate-400">Configure thresholds, validation models, and triggers</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Optimization Mode */}
                <div className="glass-panel p-6 rounded-xl space-y-4">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center">
                    <Sliders className="h-4 w-4 text-glowCyan mr-2" />
                    Intelligent Optimization Mode
                  </h3>
                  <p className="text-xs text-slate-500">
                    Controls what action occurs when the Heuristics Engine and ML Validation flags a pod as **Idle**.
                  </p>
                  
                  <div className="space-y-3">
                    {[
                      { id: 'simulation', title: 'Simulation Mode (Dry Run)', desc: 'Flags idle containers and logs optimizations to database without deleting or scaling workloads.' },
                      { id: 'manual', title: 'Manual Approval Mode', desc: 'Flags idle containers and alerts operators. Operators must approve optimizations inside the dashboard.' },
                      { id: 'automatic', title: 'Full Autopilot Mode', desc: 'Optimizes workloads immediately. Automatically triggers scaling actions on the cluster and logs reports.' }
                    ].map(mode => (
                      <label 
                        key={mode.id}
                        onClick={() => updateOptimizationMode(mode.id)}
                        className={`flex items-start space-x-3 p-4 rounded-xl border cursor-pointer hover:border-slate-700 transition ${
                          configMode === mode.id 
                            ? 'bg-slate-900/60 border-glowCyan text-slate-100' 
                            : 'bg-slate-900/20 border-slate-850 text-slate-400'
                        }`}
                      >
                        <input
                          type="radio"
                          name="opt_mode"
                          checked={configMode === mode.id}
                          onChange={() => {}}
                          className="mt-1 accent-glowCyan"
                        />
                        <div>
                          <div className={`text-xs font-bold ${configMode === mode.id ? 'text-glowCyan' : 'text-slate-300'}`}>
                            {mode.title}
                          </div>
                          <div className="text-2xs mt-1 text-slate-400 leading-tight">
                            {mode.desc}
                          </div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Algorithmic settings details */}
                <div className="glass-panel p-6 rounded-xl space-y-6">
                  <div>
                    <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-2">Algorithmic Baseline Thresholds</h3>
                    <p className="text-2xs text-slate-500">These minimum baselines prevent dynamic thresholds from falling to zero when namespaces are inactive.</p>
                  </div>

                  <div className="space-y-4 text-xs">
                    <div>
                      <div className="flex justify-between text-slate-400 font-semibold mb-1">
                        <span>Min CPU Baseline</span>
                        <span className="font-mono text-glowCyan">{config.cpu_threshold_m || 50} mCPU</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                        <div className="h-full bg-glowCyan" style={{ width: '35%' }}></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-slate-400 font-semibold mb-1">
                        <span>Min Memory Baseline</span>
                        <span className="font-mono text-glowCyan">{config.mem_threshold_mb || 50} MB</span>
                      </div>
                      <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                        <div className="h-full bg-glowCyan" style={{ width: '45%' }}></div>
                      </div>
                    </div>

                    <div className="border-t border-slate-850 pt-4 space-y-2">
                      <div className="flex justify-between">
                        <span className="text-slate-400">ML Contamination Factor:</span>
                        <span className="font-mono text-slate-200">0.25 (Isolation Forest)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Required Cycles to Flag:</span>
                        <span className="font-mono text-slate-200">{config.idle_checks_required || 2} cycles</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Heuristics Weights:</span>
                        <span className="font-mono text-slate-200">CPU (30%), Mem (25%), Net (35%), Uptime (10%)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* FOOTER BAR */}
      <footer className="bg-slate-900/30 border-t border-slate-900 px-6 py-4 flex justify-between items-center text-2xs text-slate-500">
        <div>
          2026 IdlePod Project. Developed for Cloud-Native Resource & Energy Optimization.
        </div>
        <div className="flex space-x-3 font-mono">
          <span>HOST: localhost:3000</span>
          <span>|</span>
          <span>API: localhost:8000</span>
        </div>
      </footer>
    </div>
  );
}

export default App;
